"""Competitor strategy for the Sosuke Aizen black-box explorer.

This file holds the decisions a team should tune: identity, prompts, the model
policy, and the time budget constants. The mechanics live in
``examples/blackbox_explorer/``:

- ``catalog.py`` turns discovered MCP tool definitions into a tool catalog.
- ``loop.py`` runs the LLM tool-calling exploration loop and the answer stage.
- ``answers.py`` normalizes and falls back on answers.
- ``imagery.py`` handles the image challenge branch.
- ``agent.py`` is the entrypoint (register, branch, submit, record).

Design note: the starter kit's ``BaseStrategy`` hooks are honored where they
fit (``rank_models``, ``pick_model``, ``build_system_prompt``, ``get_llm_params``,
``build_image_prompt``, ``on_time_warning``), but the explorer does not rely on
the hook surface for its control flow. Exploration is driven by the discovered
tool schemas, not by a fixed pipeline.
"""

from __future__ import annotations

import os
import re
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext


# --------------------------------------------------------------------------
# Team identity
# --------------------------------------------------------------------------

AGENT_ID = "sosuke-aizen"
AGENT_NAME = "Sosuke Aizen"


# --------------------------------------------------------------------------
# Model policy
# --------------------------------------------------------------------------
# Measured on the Practice proxy roster (2026-10 workout, logic + exploration
# prompts): these aliases answered correctly, and the first two did it in under
# two seconds with a few hundred tokens. The list is a *preference*, never a
# requirement: it is intersected with the live roster from /models, so an
# organizer roster that omits every alias here still gets a sensible ordering
# from the heuristic below.
_MEASURED_TEXT_ORDER = (
    "gpt-5.4",
    "nemotron-3.5-lightning",
    "gpt-5.6-terra",
    "gemini-3.8-flash",
    "qwen3.7-max",
    "nemotron-3-ultra",
    "gemini-3.6-flash",
    "qwen3.7-plus",
    "nemotron-3-super",
)

# Measured failure mode: these two spent the whole completion budget thinking
# and returned no answer at all on a logic puzzle. They stay usable but last.
_MEASURED_TEXT_LAST = ("qwen3.6-35b", "qwen3.7-flash")

_STRONG_NAME_TOKENS = (
    "gpt-5",
    "terra",
    "pro",
    "max",
    "ultra",
    "super",
    "plus",
    "large",
    "120b",
    "70b",
    "reason",
)
_FAST_NAME_TOKENS = ("flash", "lightning", "turbo", "fast", "mini")
_WEAK_NAME_TOKENS = ("lite", "nano", "tiny", "small", "35b", "phi", "1b", "3b")

# Image roster preference, measured on Practice with five runs per condition.
# The scored quantity is the final score, not the quality axis alone:
#   generate: flash final 87.5 [84-92] vs pro 85.6 [81-89], at higher quality
#             for pro (88.8 vs 86.6) but 23 speed points slower;
#   edit:     pro final 85.7 [83-87] vs flash 84.4 [81-87], with pro ahead on
#             quality 87.2 vs 83.8 and preservation 74.6 vs 64.6.
# So the policy is per challenge type: flash first for generation, pro first
# for edits. Both keep the measured retry order for the other family.
_IMAGE_RANK_TOKENS = ("pro", "ultra", "max", "plus", "super", "flash", "lite", "lightning")
_IMAGE_GENERATE_RANK_TOKENS = ("flash", "pro", "lite", "lightning", "turbo", "ultra", "max")


def _tokens(name: str) -> set[str]:
    """Split a model alias into comparable lowercase word tokens."""
    return {part for part in re.split(r"[^a-z0-9]+", name.lower()) if part}


def _env(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()


class MyStrategy(BaseStrategy):
    """Explorer strategy: discover, chain, verify, answer, submit."""

    agent_id = AGENT_ID
    agent_name = AGENT_NAME

    # ---- time budget (seconds) ------------------------------------------
    # A submission always happens; these reserves are what keep that promise.
    # The server stamps the submission after it judges it, so the judge's own
    # latency counts against the speed score. A measured hard-puzzle run spent
    # 85s in an optional cross-check and landed at speed 0 despite a perfect
    # answer; these reserves are what keep that from happening again.
    submit_reserve_s = 25.0        # never start an answer step inside this window
    min_useful_step_s = 6.0        # skip optional hops that cannot finish in time
    answer_timeout_s = 40.0        # hard cap on a single final-answer call
    verify_timeout_s = 15.0        # hard cap on the optional cross-check
    tool_rounds = 6                # LLM-driven exploration rounds (each may call 2 tools)
    coverage_call_limit = 12       # deterministic required-tool calls per run

    # ---- exploration protocol -------------------------------------------
    observation_char_budget = 2600     # per tool result, in the transcript
    transcript_char_budget = 14000     # total evidence handed to the answer model
    history_char_budget = 26000        # total observation text kept for the loop
    discovered_tool_escape_hatch = True

    # ---- prompts ---------------------------------------------------------
    # The stock hook prompt is used as the answer-stage system prompt. It is
    # deliberately strict about format because the judge scores exact output.
    text_system_prompt = (
        "You are the answer writer for an autonomous agent. "
        "You receive a challenge, its rules, and evidence collected by tools. "
        "Return only the answer value, formatted exactly as the rules demand. "
        "No label, no markdown, no quotes, no explanation, no trailing commentary. "
        "If the rules ask for comma-separated values, use exactly that separator. "
        "If the rules ask for one value, return one value on one line. "
        "Never answer 'unknown' when the evidence supports a concrete answer."
    )

    text_strategy_notes = (
        "Prefer exact format compliance over prose. The judge scores the value, not the reasoning."
    )
    text_temperature = 0.0
    text_max_tokens = 4096
    # The exploration loop needs room for a tool call plus a short rationale.
    explore_max_tokens = 1200
    answer_max_tokens = 3000

    image_strategy_notes = (
        "Refine the challenge prompt into one coherent image instruction, then use the "
        "best advertised image model. Keep the output standard resolution."
    )

    explorer_system_prompt = (
        "You are Sosuke Aizen, an autonomous agent that has just been dropped into an "
        "unfamiliar MCP tool server. Nobody will help you. Your job is to map the server, "
        "uncover the task, follow evidence chains, and finish with an answer.\n\n"
        "How you work:\n"
        "1. Discover before acting. The catalog below is what the server advertised. Trust "
        "each tool's input schema over its name, and never assume a tool exists that you "
        "cannot see or that the evidence did not reveal.\n"
        "2. Find the task payload first. It states the question, the output rules, and "
        "often which tools are mandatory. Nothing else matters until you have it.\n"
        "3. Follow chains. When a result hands you an identifier, a URI, a token, an "
        "encoded blob, or the name of a tool you have not called, treat that as the next "
        "hop. A tool that needs a prerequisite will fail until you fetch the prerequisite.\n"
        "4. Vary the value space. A tool that returns nothing useful under its default "
        "arguments may expose more under a declared enum value, an optional mode, or a "
        "wider scope. A dead end is often a parameter you have not varied, not a dead tool.\n"
        "5. Call every tool the challenge declares as required. Skipping one zeroes the "
        "quality score, so cover them before you finalize.\n"
        "6. Recover from failure. Read the error text: it usually names the missing "
        "argument, the wrong argument name, or the prerequisite you skipped. Change your "
        "approach rather than repeating a call that already failed the same way.\n\n"
        "Operating rules:\n"
        "- Take purposeful actions. Prefer one tool call per turn unless two calls are "
        "independent.\n"
        "- Never repeat a call whose arguments you already sent; the result is cached and "
        "re-calling wastes the clock.\n"
        "- Only probe an unlisted tool name when the evidence lists it as a tool (for "
        "example inside a tool inventory). A word that merely appears in a result is not a "
        "tool name. If a probe fails once, never probe that name again.\n"
        "- A tool that submits or finalizes an answer is held until you finalize with "
        "FINAL_ANSWER. Do not call it during exploration; the runtime submits it with its "
        "required companions once your answer exists.\n"
        "- The clock is real. Each turn tells you the seconds left. When the budget for "
        "exploration is spent, stop calling tools.\n"
        "- When you have enough evidence, reply exactly:\n"
        "  FINAL_ANSWER: <the answer value, in the exact format the rules demand>\n"
        "  with no tool calls in that turn. The label and the value are the whole reply.\n"
        "- Exploration is not the goal; a correct answer is. Once the mandatory tools are "
        "covered and the evidence answers the question, finalize on that turn instead of "
        "looking for one more tool.\n"
        "- Never fabricate evidence or claim a call you did not make."
    )

    explorer_protocol_note = (
        "Tool protocol for this deployment: you cannot emit native function calls, so reply "
        "with exactly one JSON object and nothing else:\n"
        '  {"tool": "<tool name>", "arguments": {<json arguments>}}\n'
        "When you are ready to answer, reply instead with exactly:\n"
        "  FINAL_ANSWER: <value>\n"
        "One action per reply. No prose around the JSON."
    )

    answer_prompt = (
        "Challenge statement:\n{description}\n\n"
        "Required output format (from the challenge rules):\n{rules}\n\n"
        "Evidence gathered by tools:\n{evidence}\n\n"
        "Produce the final answer now. Requirements:\n"
        "- Return only the answer value, in exactly the format the rules demand.\n"
        "- No label, no markdown, no quotes, no explanation.\n"
        "- If a clue or tool result already contains the answer verbatim, reuse that exact "
        "form.\n"
        "- If two pieces of evidence conflict, trust the challenge statement and the "
        "explicit clues over a tool's paraphrase."
    )

    verifier_prompt = (
        "You are an independent verifier. Solve the challenge from scratch using only the "
        "material below. Do not assume any earlier answer is correct; derive your own.\n\n"
        "Challenge statement:\n{description}\n\n"
        "Required output format (from the challenge rules):\n{rules}\n\n"
        "Evidence gathered by tools:\n{evidence}\n\n"
        "Return only your answer value in the required format."
    )

    resolve_disagreement_prompt = (
        "Two independent solvers returned different answers to the same challenge. Decide "
        "the correct answer yourself from the challenge, its rules, and the evidence. "
        "Check the required output format especially carefully.\n\n"
        "Challenge statement:\n{description}\n\n"
        "Required output format:\n{rules}\n\n"
        "Evidence:\n{evidence}\n\n"
        "Candidate A: {first}\n"
        "Candidate B: {second}\n\n"
        "Return only the answer value in the required format."
    )

    image_prompt_refiner = (
        "You write prompts for image generation and image editing models. You receive the "
        "challenge's own image instruction and reference notes.\n\n"
        "Start your answer with the challenge instruction, kept verbatim and complete. "
        "Then add at most 60 words of visual direction that raises render quality without "
        "changing it:\n"
        "- keep every explicit requirement and constraint, including any prohibition;\n"
        "- if text is prohibited, explicitly forbid all text, letters, numbers, logos, "
        "signs, and watermarks;\n"
        "- if an input image is being edited, state what must be preserved and what must "
        "change;\n"
        "- add concrete direction only for composition, lighting, materials, colour, mood, "
        "and lens;\n"
        "- never introduce a different subject, scene, or extra objects;\n"
        "- stay under {max_chars} characters and contain no meta-commentary.\n\n"
        "Return only the prompt text."
    )

    # ---- hook overrides ---------------------------------------------------
    def is_image_challenge(self, ctx: ChallengeContext) -> bool:
        return "image" in ctx.challenge_type.strip().lower() or bool(ctx.image_url)

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Rank the live roster for this challenge.

        Image challenges rank image-capable aliases only (falling back to the
        whole roster if the proxy advertises none). Text challenges rank
        measured winners first, then every remaining alias by a name heuristic,
        then the measured token-burners last.
        """
        models = [str(model).strip() for model in available_models if str(model).strip()]
        if not models:
            return []

        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(models)
            editing = "edit" in str(ctx.challenge_type or "").casefold()
            order = _IMAGE_RANK_TOKENS if editing else _IMAGE_GENERATE_RANK_TOKENS
            image_ranked = sorted(image_models, key=lambda name: self._image_rank_key(name, order))
            # Dev knob for measured image experiments: force one advertised
            # image alias first. Unset (the shipped default) keeps the ranked
            # order; an alias that is not on the live roster is ignored.
            forced = _env("EXPLORER_IMAGE_MODEL")
            if forced and forced in models:
                image_ranked = [forced, *[name for name in image_ranked if name != forced]]
            # Keep a usable text ranking after the image aliases: the image
            # branch still needs a text model to plan and refine the prompt.
            image_set = set(image_models)
            text_ranked = self._text_order([model for model in models if model not in image_set])
            return image_ranked + text_ranked if image_ranked else text_ranked
        return self._text_order(models)

    def _text_order(self, models: list[str]) -> list[str]:
        """Measured winners first, then name-heuristic order, burners last."""
        measured = {name.casefold(): index for index, name in enumerate(_MEASURED_TEXT_ORDER)}
        burners = {name.casefold() for name in _MEASURED_TEXT_LAST}
        present = {model.casefold() for model in models}
        ordered: list[str] = [name for name in _MEASURED_TEXT_ORDER if name.casefold() in present]
        rest = [
            model
            for model in models
            if model.casefold() not in measured and model.casefold() not in burners
        ]
        rest.sort(key=lambda name: (-self._text_heuristic(name), name.casefold()))
        ordered.extend(rest)
        ordered.extend(name for name in _MEASURED_TEXT_LAST if name.casefold() in present)
        by_fold = {model.casefold(): model for model in models}
        result: list[str] = []
        seen: set[str] = set()
        for name in ordered:
            actual = by_fold.get(name.casefold(), name)
            if actual.casefold() in seen:
                continue
            seen.add(actual.casefold())
            result.append(actual)
        return result

    def pick_model(
        self,
        stage: str,
        ranked_models: list[str],
        ctx: ChallengeContext,
    ) -> str:
        """Choose a model per stage.

        ``solve``/``explore``/``answer`` take the top ranked alias. ``verify``
        takes a *different* model when one exists, because an independent blind
        solve is only useful if it is not the same mind again. On easy
        challenges the verifier is skipped by the caller, so this stays cheap.
        """
        if not ranked_models:
            return ""
        normalized_stage = str(stage or "").strip().lower()
        if normalized_stage == "verify" and len(ranked_models) > 1:
            return ranked_models[1]
        return ranked_models[0]

    def should_verify(self, ctx: ChallengeContext, remaining_s: float) -> bool:
        """Run a second blind solve only when it can pay for itself.

        Quality is 0.7 of the score, but a second solve costs clock, so it is
        reserved for challenges where a wrong answer is plausible and there is
        time to spare.
        """
        # Leave room for the cross-check, the final submit, and the judge.
        if remaining_s < max(self.verify_timeout_s + 20.0, 0.55 * ctx.max_time_s):
            return False
        return ctx.difficulty.strip().lower() in {"hard", "medium", "unknown", ""}

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        _ = ctx
        return str(self.text_system_prompt).strip()

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        """Expose the answer prompt through the standard hook surface."""
        evidence = "\n".join(f"- {clue}" for clue in ctx.clues if str(clue).strip())
        return self.answer_prompt.format(
            description=self._describe(ctx),
            rules=self._rules(ctx),
            evidence=evidence or "- (no structured evidence)",
        )

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        return {
            "temperature": float(self.text_temperature),
            "max_tokens": int(self.text_max_tokens),
        }

    def on_time_warning(
        self,
        remaining_s: float,
        current_answer: str,
        ctx: ChallengeContext,
    ) -> str | None:
        """Never trade a real answer for an empty one, even under pressure."""
        _ = remaining_s
        _ = ctx
        return current_answer or None

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Fallback image prompt when no LLM refinement is possible."""
        instruction = ctx.rules.strip() or ctx.challenge_text.strip() or ctx.description.strip()
        return (
            f"{instruction}\n\n"
            "One coherent, high-quality image. Standard resolution, no text or watermark "
            "unless the instruction explicitly asks for it."
        )

    # ---- internals --------------------------------------------------------
    @staticmethod
    def _text_heuristic(name: str) -> int:
        """Name-based quality guess for an unseen text alias."""
        lowered = name.casefold()
        tokens = _tokens(lowered)
        score = 0
        if any(token in lowered for token in _STRONG_NAME_TOKENS):
            score += 3
        if any(token in lowered for token in _FAST_NAME_TOKENS):
            score += 1
        if any(token in lowered for token in _WEAK_NAME_TOKENS):
            score -= 3
        # A generic large-parameter tag usually beats a tiny one.
        if re.search(r"\b\d{2,3}b\b", lowered) and "35b" not in lowered:
            score += 1
        if "image" in tokens:
            score -= 8
        return score

    @staticmethod
    def _image_rank_key(name: str, order: tuple[str, ...] = _IMAGE_RANK_TOKENS) -> tuple[int, str]:
        lowered = name.casefold()
        for index, token in enumerate(order):
            if token in _tokens(lowered):
                return (index, lowered)
        return (len(order), lowered)

    @staticmethod
    def _describe(ctx: ChallengeContext) -> str:
        parts = []
        if ctx.description.strip():
            parts.append(ctx.description.strip())
        if ctx.challenge_text.strip() and ctx.challenge_text.strip() != ctx.description.strip():
            parts.append(ctx.challenge_text.strip())
        return "\n".join(parts) or "(no challenge statement provided)"

    @staticmethod
    def _rules(ctx: ChallengeContext) -> str:
        return ctx.rules.strip() or "(no explicit format rules; answer with the shortest correct value)"
