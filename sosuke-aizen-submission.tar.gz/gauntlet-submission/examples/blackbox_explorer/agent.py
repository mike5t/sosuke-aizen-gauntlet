#!/usr/bin/env python3
"""Sosuke Aizen - autonomous explorer agent for Agent Gauntlet.

Entrypoint flow:

    register -> discover MCP tools -> detect modality -> bootstrap the task
    payload -> satisfy mandatory tools -> LLM tool-calling exploration loop
    -> answer (with an independent cross-check) -> submit -> run record

Design goals, in the order they are traded off:

1. Always submit before the deadline. A hard budget guard cancels the solve
   phase early and submits the best value the run produced, or a deterministic
   format-plausible fallback.
2. Maximize quality. The answer stage quotes the challenge rules verbatim,
   normalizes to the demanded shape, and cross-checks with a second model.
3. Spend the clock and tokens only where they buy quality.

No tool name is hardcoded. Every tool call is chosen from the catalog built
from ``list_tool_defs()``; the mandatory-tool pass is driven by the tool names
the challenge payload itself declares.

Usage:
    cd <repo root>
    python examples/blackbox_explorer/agent.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
for _path in (str(REPO_ROOT), str(HERE)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

try:
    from dotenv import load_dotenv

    load_dotenv(REPO_ROOT / ".env")
except ImportError:  # dotenv is optional when the runner supplies the env
    pass

from arena_clients import (
    ArenaAPIError,
    ArenaConnectionError,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
)
from arena_clients.config import agent_id_problem
from arena_clients.display import (
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.mcp_client import ChallengeInfo, ImageChallengeInfo
from arena_clients.outputs import missing_tools_note, save_submitted_image
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import ChallengeContext
from model_selector import fetch_available_models

import answers
import loop
from catalog import ToolCatalog
from imagery import ImageRunner, ImageOutcome
from my_strategy import AGENT_ID, AGENT_NAME, MyStrategy


def _int(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _console(line: str = "") -> None:
    print(line, flush=True)


# ---------------------------------------------------------------------------
# Challenge views (display only)
# ---------------------------------------------------------------------------


def _find(payload: dict[str, Any], keys: tuple[str, ...], default: Any = "") -> Any:
    for key, value in payload.items():
        if key.casefold() in keys and value not in (None, ""):
            return value
    return default


def challenge_view(payload: dict[str, Any], *, image: bool) -> Any:
    """Wrap a raw payload in the display dataclasses the kit already prints."""
    if image:
        prompt = _find(payload, ("prompt", "edit_prompt", "image_prompt", "instruction"))
        if not isinstance(prompt, str):
            prompt = ""
        return ImageChallengeInfo(
            challenge_type=str(_find(payload, ("challenge_type", "type", "kind"), "image")),
            challenge_id=str(_find(payload, ("challenge_id", "id"), "")),
            puzzle_id=str(_find(payload, ("puzzle_id", "id"), "")),
            difficulty=str(_find(payload, ("difficulty", "level"), "unknown")),
            description=str(_find(payload, ("description", "task"), "")),
            prompt=prompt,
            reference_notes=str(_find(payload, ("reference_notes", "notes"), "")),
            max_time_s=_int(_find(payload, ("max_time_s", "time_limit_s"), 0)),
            input_image_uri=str(_find(payload, ("input_image_uri", "source_image_uri"), "")),
            time_remaining_s=float(_find(payload, ("time_remaining_s",), 0) or 0),
        )
    clues = _find(payload, ("clues", "hints"), [])
    if isinstance(clues, list):
        clues = [
            item.get("text", "") if isinstance(item, dict) else str(item)
            for item in clues
        ]
    else:
        clues = []
    return ChallengeInfo(
        challenge_type=str(_find(payload, ("challenge_type", "type", "kind"), "text")),
        challenge_id=str(_find(payload, ("challenge_id", "id"), "")),
        puzzle_id=str(_find(payload, ("puzzle_id", "id"), "")),
        description=str(_find(payload, ("description", "question"), "")),
        rules=str(_find(payload, ("rules", "output_format", "format"), "")),
        max_time_s=_int(_find(payload, ("max_time_s", "time_limit_s"), 0)),
        clues=[str(clue) for clue in clues if str(clue).strip()],
        time_remaining_s=float(_find(payload, ("time_remaining_s",), 0) or 0),
        raw_data=dict(payload),
    )


def _score_lines(score: Any) -> list[str]:
    """Axis-by-axis score breakdown for the console."""
    if not isinstance(score, dict):
        return []
    lines: list[str] = []
    final = score.get("final_score")
    if final is not None:
        lines.append(f"   Score: {final}")
    for label, key in (
        ("Quality", "quality_score"),
        ("Speed", "speed_score"),
        ("Tools", "tools_score"),
        ("Models", "models_score"),
        ("Tokens", "tokens_score"),
    ):
        if score.get(key) is not None:
            lines.append(f"   {label}: {score[key]}")
    judge = score.get("judge")
    if isinstance(judge, dict) and judge.get("rationale"):
        lines.append(f"   Judge: {str(judge['rationale'])[:200]}")
        if judge.get("score") is not None:
            lines.append(f"   Judge score: {judge['score']}")
    if score.get("broadcast_penalty_applied"):
        lines.append(
            f"   Broadcast penalty: {score.get('broadcast_penalty_pct')}% "
            f"({score.get('broadcast_thought_count')} thoughts)"
        )
    if score.get("judge_error"):
        lines.append(f"   Judge error: {score['judge_error']}")
    return lines


def _score_record(score: Any) -> Any:
    """Drop inline image data from a score payload before it hits disk."""
    if not isinstance(score, dict):
        return score
    cleaned = {}
    for key, value in score.items():
        if isinstance(value, str) and value.startswith("data:") and len(value) > 200:
            cleaned[key] = f"<inline image, {len(value)} chars>"
        else:
            cleaned[key] = value
    return cleaned


# ---------------------------------------------------------------------------
# Time tool discovery
# ---------------------------------------------------------------------------


def _time_tool(catalog: ToolCatalog) -> str:
    """The discovered tool that reports the clock, if any."""
    for name in catalog.time_candidates():
        spec = catalog.get(name)
        if spec is None:
            continue
        if spec.required_props() and not set(p.lower() for p in spec.required) <= {
            "agent_id",
            "agentid",
            "session_id",
        }:
            continue
        return name
    return ""


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------


async def run() -> int:
    strategy = MyStrategy()
    agent_id = (os.getenv("AGENT_ID") or getattr(strategy, "agent_id", "") or AGENT_ID).strip()
    agent_name = (os.getenv("AGENT_NAME") or getattr(strategy, "agent_name", "") or AGENT_NAME).strip()
    os.environ["AGENT_ID"] = agent_id
    os.environ["AGENT_NAME"] = agent_name

    problem = agent_id_problem(agent_id)
    if problem:
        raise SystemExit(f"❌ {problem}")

    ensure_connected()
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()

    _console(f"🤖 {agent_name} starting")
    _console(f"   Agent ID: {agent_id}")
    _console(f"   API: {api_base}")

    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)
    session = http_client.register(agent_id, agent_name)
    registered_at = time.monotonic()
    _console(f"   Session: {session.session_id} ({session.status})")

    # Dev knob for measured experiments only. The session already names the
    # assigned puzzle before any challenge tool is called, so a lost assignment
    # race can be abandoned without touching the challenge clock or the image
    # gate. Unset (the shipped default) never aborts.
    target_puzzle = (os.getenv("EXPLORER_TARGET_PUZZLE") or "").strip()
    if target_puzzle:
        # Measurement only: re-register until this process owns the requested
        # puzzle. The walk happens before any challenge tool, so a discarded
        # assignment costs a second and never touches the image gate.
        try:
            target_retries = max(0, int(os.getenv("EXPLORER_TARGET_RETRIES") or "0"))
        except ValueError:
            target_retries = 0
        for _attempt in range(target_retries + 1):
            try:
                assigned = str(
                    (http_client.get_session(agent_id).get("metrics") or {}).get("challenge_id")
                    or ""
                )
            except Exception:
                assigned = ""
            if not assigned or assigned == target_puzzle:
                break
            _console(f"   Target mismatch ({assigned}); re-registering")
            session = http_client.register(agent_id, agent_name)
            registered_at = time.monotonic()
        else:
            _console(f"   Could not obtain {target_puzzle}; exiting before the challenge")
            raise SystemExit(3)

    try:
        from openai import OpenAI
    except ImportError as exc:  # pragma: no cover - environment guard
        raise SystemExit("Missing dependency: openai.") from exc

    usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
    if usage_scope:
        os.environ["ARENA_USAGE_SCOPE"] = usage_scope
    llm_client = OpenAI(
        base_url=llm_host,
        api_key=api_key,
        default_headers=build_proxy_headers(agent_id, usage_scope),
    )

    def think(thought: str) -> None:
        """Broadcast a thought. Scoring drops 10% below one thought per run."""
        text = str(thought or "").strip()
        if not text:
            return
        try:
            http_client.broadcast_thought(agent_id, text[:400])
        except Exception:
            pass

    exit_code = 0
    async with McpArenaClient(mcp_url) as mcp:
        tool_defs = await mcp.list_tool_defs()
        catalog = ToolCatalog(tool_defs)
        tools = catalog.names
        # The registered session is the authoritative assignment and it is one
        # cheap REST call. detect_modality() falls back to a text-biased tool
        # heuristic when its own session lookup is slow, which silently solves
        # the wrong modality, so use it only as a fallback here.
        modality = ""
        modality_source = "session"
        try:
            session_state = http_client.get_session(agent_id)
            modality = str(
                session_state.get("challenge_type")
                or (session_state.get("metrics") or {}).get("challenge_type")
                or ""
            ).strip().casefold()
        except Exception:
            modality = ""
        if modality not in {"text", "image"}:
            modality_source = "fallback"
            modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)
        is_image = modality == "image"
        _console(
            f"   MCP: {len(catalog)} tools discovered; modality: {modality} "
            f"({modality_source})"
        )
        think(
            f"Connected. {len(catalog)} tools discovered; challenge modality is {modality}."
        )

        available_models = fetch_available_models(llm_host, api_key)
        probe_ctx = ChallengeContext(
            challenge_type=modality,
            description="",
            rules="",
            max_time_s=120,
            available_models=available_models,
        )
        ranked_models = strategy.rank_models(probe_ctx, available_models)
        if not ranked_models:
            exit_code = 1
            raise SystemExit("No models were advertised by the LLM proxy.")
        _console(f"   Models: {len(ranked_models)} ranked, primary {ranked_models[0]}")

        llm = loop.LLM(llm_client, agent_id)
        time_tool = _time_tool(catalog)

        async def read_clock() -> dict[str, Any]:
            if not time_tool:
                return {}
            return await mcp.call_tool(time_tool, {"agent_id": agent_id})

        clock = loop.ArenaClock(max_time_s=0, sync=read_clock)

        explorer = loop.Explorer(
            mcp=mcp,
            catalog=catalog,
            strategy=strategy,
            llm=llm,
            clock=clock,
            agent_id=agent_id,
            ranked_models=ranked_models,
            think=think,
            log=_console,
            image_assignment=is_image,
        )

        bootstrap_started = time.monotonic()
        await explorer.bootstrap(image=is_image)
        if not explorer.has_challenge_payload:
            # The server did not hand over a task through the obvious tools.
            # Explore for it, then re-read the modality from what was found.
            # The arena's assignment still wins for image challenges.
            _console("   No task payload at bootstrap; exploring to locate it")
            await explorer.explore(rounds=strategy.tool_rounds)
            discovered_image = bool(explorer.image_uri) or "image" in explorer.challenge_type.casefold()
            is_image = is_image or discovered_image
        payload = explorer.challenge or {}
        view = challenge_view(payload, image=is_image)
        print_challenge(view)
        _console(f"   Bootstrap: {explorer.challenge_tool or '(none)'} in "
                 f"{time.monotonic() - bootstrap_started:.1f}s")

        ctx = explorer.context()
        ranked_models = strategy.rank_models(ctx, available_models) or ranked_models
        explorer.ranked_models = ranked_models

        solve_started = time.monotonic()
        image_outcome = ImageOutcome()
        submit_extra: dict[str, Any] = {}

        if is_image:
            runner = ImageRunner(
                explorer=explorer,
                catalog=explorer.catalog,
                strategy=strategy,
                ranked_models=ranked_models,
                think=think,
                log=_console,
            )
            budget = _solve_budget(explorer, strategy)
            try:
                image_outcome = await asyncio.wait_for(runner.run(), timeout=budget)
            except asyncio.TimeoutError:
                image_outcome = runner.outcome
                _console(f"   ⏱  Image deadline guard fired with {clock.remaining():.0f}s left")
            if image_outcome.image_uri:
                think(f"Image ready via {image_outcome.tool}; submitting.")
            answer = image_outcome.image_uri
            # Cover any required tools the render chain did not touch.
            if explorer.missing_required():
                await explorer.cover_required_tools(call_limit=strategy.coverage_call_limit)
        else:
            budget = _solve_budget(explorer, strategy)
            try:
                await asyncio.wait_for(
                    _solve_text(explorer, strategy), timeout=budget
                )
            except asyncio.TimeoutError:
                explorer.timed_out = True
                _console(f"   ⏱  Solve deadline guard fired with {clock.remaining():.0f}s left")
            answer = explorer.candidate or explorer.answer_sync_fallback()

            if not answer:
                remaining = clock.remaining()
                if remaining > strategy.submit_reserve_s + 8:
                    answer = await asyncio.wait_for(
                        explorer.answer(),
                        timeout=max(6.0, remaining - strategy.submit_reserve_s - 3),
                    )
                else:
                    answer = explorer.answer_sync_fallback()

        solve_elapsed_ms = int((time.monotonic() - solve_started) * 1000)
        if not is_image:
            # Deterministic last step: strip labels, fences, quotes, and any
            # shape the challenge rules explicitly forbid before it reaches
            # the judge. Image payloads must never pass through text cleanup.
            answer = answers.finalize_for_submit(answer, explorer.rules)
        metrics = _build_metrics(
            model=(image_outcome.model or (ranked_models[0] if ranked_models else "")),
            usage=llm.usage,
            total_time_ms=solve_elapsed_ms,
        )

        # ---- submit -----------------------------------------------------
        http_client.save_draft(agent_id, answer[:8000] or "", "explorer draft")
        think(f"Submitting final answer ({len(answer)} chars).")
        if is_image:
            result, used_rest = await _submit_image(
                explorer=explorer,
                runner=runner,
                outcome=image_outcome,
                http_client=http_client,
                agent_id=agent_id,
                metrics=metrics,
                fallback_answer=answer,
            )
            submit_extra["submitted_via"] = "rest" if used_rest else "mcp"
        else:
            result = _submit_text(http_client, agent_id, answer, metrics)

        score = getattr(result, "score", None)
        if score is None and isinstance(result, dict):
            score = result.get("score")
        accepted = getattr(result, "accepted", None)
        status = getattr(result, "status", None)
        if isinstance(result, dict):
            accepted = result.get("accepted", accepted)
            status = result.get("status", status)
        _console("")
        _console("📤 Submission")
        _console(f"   Accepted: {accepted}")
        if status:
            _console(f"   Status: {status}")
        for line in _score_lines(score):
            _console(line)
        note = missing_tools_note(result)
        if note:
            _console(f"   ⚠️  {note}")
        total_elapsed_ms = int((time.monotonic() - registered_at) * 1000)
        _console(f"   Elapsed: {total_elapsed_ms / 1000:.1f}s, "
                 f"tokens: {llm.usage.total_tokens}, model calls: {llm.usage.requests}")

        if is_image and image_outcome.image_uri:
            _console(f"   Image: {save_submitted_image(agent_id, image_outcome.image_uri, REPO_ROOT)}")

        record = {
            "agent_id": agent_id,
            "entrypoint": "examples/blackbox_explorer/agent.py",
            "modality": modality,
            "challenge": challenge_record(view),
            "tools_discovered": catalog.names,
            "required_tools": explorer.required_tools,
            "missing_required_tools": explorer.missing_required(),
            "models_ranked": ranked_models,
            "models_used": explorer.models_used or ([image_outcome.model] if image_outcome.model else []),
            "exploration_rounds": explorer.rounds,
            "tool_calls": [
                {
                    "tool": observation.tool,
                    "arguments": observation.arguments,
                    "ok": observation.ok,
                    "error": observation.error,
                    "elapsed_s": round(observation.elapsed_s, 2),
                }
                for observation in explorer.observations
            ],
            "answer": answer if not is_image else "<image>",
            "image": {
                "tool": image_outcome.tool,
                "model": image_outcome.model,
                "prompt": image_outcome.prompt,
                "attempts": image_outcome.attempts,
                "error": image_outcome.error,
            }
            if is_image
            else {},
            "usage": llm.usage.as_metrics() | {"requests": llm.usage.requests},
            "solve_elapsed_ms": solve_elapsed_ms,
            "total_elapsed_ms": total_elapsed_ms,
            "result": {
                "accepted": accepted,
                "status": status,
                "score": _score_record(score),
                **submit_extra,
            },
        }
        _console(f"   Run record: {save_run_record(agent_id, record, REPO_ROOT)}")
        _console("")
        _console("✅ Run complete")
    return exit_code


def _solve_budget(explorer: loop.Explorer, strategy: MyStrategy) -> float:
    """Seconds the solve phase may consume before the guard submits."""
    remaining = explorer.clock.remaining()
    if remaining == float("inf") or remaining <= 0:
        return 120.0
    return max(5.0, remaining - strategy.submit_reserve_s)


async def _solve_text(
    explorer: loop.Explorer,
    strategy: MyStrategy,
) -> None:
    """Coverage, exploration, and the answer stage inside one cancellable task."""
    missing = await explorer.cover_required_tools(call_limit=strategy.coverage_call_limit)
    explorer._think(
        f"Required tools covered ({len(explorer.required_tools) - len(missing)} of "
        f"{len(explorer.required_tools)}); exploring with {len(explorer.clues)} clues."
    )
    await explorer.explore(rounds=strategy.tool_rounds)
    if explorer.missing_required():
        # A nested challenge discovered mid-loop declares its own required
        # tools; cover those before answering too.
        await explorer.cover_required_tools(call_limit=strategy.coverage_call_limit)
    # Always run the answer stage, even when exploration already produced a
    # value: it normalizes the shape and, when the clock allows, cross-checks
    # with an independent blind solve. On easy puzzles the cross-check is
    # skipped, so this costs nothing there.
    answer = await explorer.answer()
    if answer:
        explorer.candidate = answer
    if explorer.candidate:
        # A discovered submit tool carries the answer to the server that asked
        # for it; the arena's REST submission still follows in the entrypoint.
        await explorer.submit_answer_via_tool(explorer.candidate)
    missing = explorer.missing_required()
    if missing:
        explorer._log(f"   Uncovered required tools: {', '.join(missing)}")


def _build_metrics(model: str, usage: loop.Usage, total_time_ms: int) -> dict[str, Any]:
    return {
        "model_name": str(model or "").strip(),
        "prompt_tokens": str(usage.prompt_tokens),
        "completion_tokens": str(usage.completion_tokens),
        "total_tokens": str(usage.total_tokens),
        "ttft_ms": int(usage.first_token_ms),
        "total_time_ms": int(max(0, total_time_ms)),
    }


def _submit_text(
    http_client: HttpArenaClient,
    agent_id: str,
    answer: str,
    metrics: dict[str, Any],
):
    """Submit the text answer, retrying the exact same answer on a lost reply."""
    payload = answer if answer.strip() else "unknown"
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            return http_client.submit(agent_id=agent_id, answer=payload, client_metrics=metrics)
        except ArenaAPIError as exc:
            # A 409 means a different answer is already official; retrying
            # cannot replace it, so surface the receipt-style failure instead.
            _console(f"   Submit rejected ({exc.status_code}): {str(exc.message)[:200]}")
            raise
        except ArenaConnectionError as exc:
            last_error = exc
            _console(f"   Submit transport error ({attempt + 1}/2): {exc}")
            if attempt == 0:
                time.sleep(0.6)
    assert last_error is not None
    raise last_error


async def _submit_image(
    *,
    explorer: loop.Explorer,
    runner: ImageRunner,
    outcome: ImageOutcome,
    http_client: HttpArenaClient,
    agent_id: str,
    metrics: dict[str, Any],
    fallback_answer: str,
) -> tuple[Any, bool]:
    """Submit the image through the discovered tool, then REST as a fallback."""
    if outcome.image_uri:
        result = await runner.submit(
            outcome,
            client_metrics=metrics,
            rationale="Black-box explorer: discovered chain, refined prompt, best image model.",
        )
        if result:
            return result, False
        _console("   MCP image submit unavailable; submitting image over REST")
    payload = outcome.image_uri or fallback_answer
    try:
        result = http_client.submit(
            agent_id=agent_id,
            answer=payload,
            client_metrics=metrics,
            challenge_type="image",
        )
        return result, True
    except ArenaAPIError as exc:
        _console(f"   Image submit rejected ({exc.status_code}): {str(exc.message)[:200]}")
        raise


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(run()))
    except KeyboardInterrupt:
        raise SystemExit(130)
    except McpArenaError as exc:
        _console(f"❌ MCP error: {exc}")
        raise SystemExit(1)
    except (ArenaAPIError, ArenaConnectionError) as exc:
        _console(f"❌ Arena error: {exc}")
        raise SystemExit(1)
