"""Answer extraction, format compliance, and deterministic fallbacks.

The judge scores correctness *and* exact output format, so the last thing that
touches an answer is deterministic code, not a model: labels get stripped,
markdown fences get removed, and the value is trimmed to what the challenge
rules asked for.

The fallback path exists so a submission always happens. It never pretends to
be certain; it produces the most format-plausible guess available from the
evidence, which is strictly better than a missing answer or the literal string
"unknown".
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

_LABEL_PATTERN = re.compile(
    r"(?:final[_ ]?answer|answer|solution|result)\s*[:\-]\s*",
    flags=re.IGNORECASE,
)
_FENCE_PATTERN = re.compile(r"```[a-zA-Z0-9_+-]*\s*(.*?)```", flags=re.DOTALL)
_TOOL_MARKUP = ("<toolcall", "</toolcall", "<tool_call", "</tool_call", "function_call", '"tool_calls"')
_THINK_PATTERN = re.compile(r"<think\b.*?(?:</think\s*>|$)", flags=re.DOTALL | re.IGNORECASE)
_QUOTE_CHARS = " \t\r\n`\"'“”‘’"
_REFUSAL_MARKERS = (
    "i cannot",
    "i can't",
    "i am unable",
    "i'm unable",
    "unable to complete",
    "not provided",
    "no challenge statement",
    "failed to retrieve",
    "as an ai",
    "i don't have enough",
)


@dataclass(frozen=True)
class AnswerShape:
    """What the challenge rules say the answer should look like."""

    comma_separated: bool = False
    one_per_line: bool = False
    json_object: bool = False
    uppercase: bool = False
    lowercase: bool = False
    single_value: bool = False

    @property
    def multiline(self) -> bool:
        return self.one_per_line and not self.single_value


def read_shape(rules: str) -> AnswerShape:
    """Detect the demanded output shape from the challenge's own rules."""
    text = str(rules or "").casefold()
    comma = bool(
        re.search(r"comma[\s-]*separated|comma[\s-]*delimited|separated by commas?", text)
    )
    per_line = bool(
        re.search(r"one (?:per|on each|value per) line|each on (?:its|a) own line|line[- ]separated", text)
    )
    json_object = bool(re.search(r"\bjson\b", text))
    single_value = bool(
        re.search(r"return only|only the|single|one (?:value|word|answer)|no extra|no commentary", text)
    ) and not comma and not per_line
    return AnswerShape(
        comma_separated=comma,
        one_per_line=per_line,
        json_object=json_object,
        uppercase=bool(re.search(r"uppercase|upper-case|capital letters", text)),
        lowercase=bool(re.search(r"lowercase|lower-case", text)),
        single_value=single_value,
    )


def strip_wrappers(raw: str) -> str:
    """Remove fences, thinking traces, and a leading answer label."""
    text = str(raw or "")
    text = _THINK_PATTERN.sub(" ", text)
    fences = _FENCE_PATTERN.findall(text)
    if fences:
        # Prefer the last fenced block: a model that shows its work puts the
        # final value last.
        text = fences[-1]
    text = _LABEL_PATTERN.sub(" ", text, count=1).strip()
    return text


def extract_labeled_answer(raw: str) -> str:
    """Take the value after the last ``ANSWER:`` / ``FINAL_ANSWER:`` label."""
    text = _THINK_PATTERN.sub(" ", str(raw or ""))
    matches = list(_LABEL_PATTERN.finditer(text))
    if not matches:
        return ""
    last = matches[-1]
    tail = text[last.end():]
    # The value is the remainder of that line, or the rest of the reply.
    line = tail.splitlines()[0].strip() if tail.strip() else ""
    if not line:
        line = tail.strip()
    return line.strip(_QUOTE_CHARS)


def extract_json_answer(raw: str) -> str:
    """Find an answer-shaped value inside a JSON reply."""
    text = str(raw or "").strip()
    candidates = re.findall(r"\{.*?\}", text, flags=re.DOTALL)
    for candidate in reversed(candidates):
        try:
            payload = json.loads(candidate)
        except (TypeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        for key in ("final_answer", "answer", "solution", "result", "value", "output"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, (int, float, bool)):
                return str(value)
            if isinstance(value, list) and all(isinstance(item, (str, int, float)) for item in value):
                return ", ".join(str(item) for item in value)
    return ""


def looks_like_tool_markup(text: str) -> bool:
    lowered = str(text or "").casefold()
    return any(token in lowered for token in _TOOL_MARKUP)


def looks_like_tool_name(text: str, known_tools: tuple[str, ...] = ()) -> bool:
    """True for a value that is really a tool identifier, not an answer."""
    value = str(text or "").strip()
    if not value or " " in value or len(value) > 120:
        return False
    if value in known_tools:
        return True
    return bool(re.fullmatch(r"[a-z0-9_-]+(?:\.[a-z0-9_-]+)+", value.casefold()))


def looks_like_payload_uri(text: str) -> bool:
    """True for an image/asset payload, which is never a text answer value."""
    value = str(text or "").strip()
    if value.startswith("data:"):
        return True
    return bool(re.match(r"https?://\S+$", value))


def looks_like_refusal(text: str) -> bool:
    lowered = str(text or "").casefold()
    return any(marker in lowered for marker in _REFUSAL_MARKERS)


def is_usable_answer(
    text: str,
    *,
    max_chars: int = 20000,
    known_tools: tuple[str, ...] = (),
) -> bool:
    """Reject empty, markup, refusal, and tool-identifier-shaped answers."""
    value = str(text or "").strip()
    if not value or len(value) > max_chars:
        return False
    if looks_like_tool_markup(value):
        return False
    if looks_like_refusal(value):
        return False
    if looks_like_tool_name(value, known_tools):
        return False
    if looks_like_payload_uri(value):
        return False
    if value.casefold() in {"unknown", "none", "n/a", "null", "undefined"}:
        return False
    if re.fullmatch(r"[\W_]+", value):
        return False
    # A decode tool with the wrong key still returns bytes. If a large share of
    # the value is control characters, it is garbage, not an answer.
    control = sum(1 for char in value if ord(char) < 32 and char not in "\n\r\t")
    if control and control / max(1, len(value)) > 0.05:
        return False
    return True


def normalize_answer(raw: str, rules: str = "") -> str:
    """Turn a model reply into the exact value that should be submitted."""
    shape = read_shape(rules)
    text = str(raw or "").strip()
    if not text:
        return ""
    labeled = extract_labeled_answer(text)
    if labeled:
        text = labeled
    else:
        text = strip_wrappers(text)
    if not text:
        return ""
    if shape.json_object and text.startswith("{") is False:
        embedded = extract_json_answer(text)
        if embedded:
            text = embedded
    if shape.uppercase:
        text = text.upper()
    elif shape.lowercase:
        text = text.lower()
    # Collapse a model's habit of adding a second paragraph after the value.
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return ""
    if shape.multiline:
        text = "\n".join(lines)
    elif len(lines) > 1:
        # Unlabeled reasoning puts the value last; a labeled value stays first.
        text = lines[0] if labeled else lines[-1]
    else:
        text = lines[0]
    text = text.strip(_QUOTE_CHARS)
    text = re.sub(r"[ \t]+", " ", text)
    return text


def answers_agree(first: str, second: str) -> bool:
    """Compare two answers ignoring spacing, case, and surrounding punctuation."""
    def canonical(value: str) -> str:
        text = str(value or "").casefold()
        return re.sub(r"[\s\"'`.,;:!?]+", " ", text).strip()

    return bool(canonical(first)) and canonical(first) == canonical(second)


_IDENTIFIER_PATTERNS = (
    re.compile(r"\b([A-Z]{1,3}[-_ ]?\d{1,3})\b"),
    re.compile(r"\b([a-z]+[-_]\d{1,3})\b"),
)


def identifier_tokens(text: str) -> list[str]:
    """Ordered, de-duplicated identifiers such as ``E3`` or ``item-4``."""
    seen: dict[str, None] = {}
    for pattern in _IDENTIFIER_PATTERNS:
        for match in pattern.finditer(str(text or "")):
            token = match.group(1).strip()
            key = re.sub(r"[\s_-]+", "", token).casefold()
            if key not in seen:
                seen[key] = None
    return list(seen)


def _ordered_identifiers(clues: list[str], description: str) -> list[str]:
    """Identifiers in the order the puzzle introduces them."""
    ordered: list[str] = []
    seen: set[str] = set()
    for chunk in list(clues) + [description]:
        for token in identifier_tokens(chunk):
            key = re.sub(r"[\s_-]+", "", token).casefold()
            if key in seen:
                continue
            seen.add(key)
            ordered.append(token)
    return ordered


def plausible_fallback(clues: list[str], description: str, rules: str, evidence: str = "") -> str:
    """Format-plausible guess from the identifiers the puzzle itself names.

    Used only when the clock ran out before any model produced a value. It
    keeps the shape the rules demand, which is the difference between a
    malformed reply and a partially credited one.
    """
    shape = read_shape(rules)
    identifiers = _ordered_identifiers(clues, description)
    if not identifiers and evidence:
        identifiers = identifier_tokens(evidence)
    if identifiers:
        if shape.one_per_line:
            return "\n".join(identifiers)
        return ", ".join(identifiers)
    # No identifiers anywhere: answer with the challenge's most answer-shaped
    # evidence line rather than a refusal.
    for line in reversed([line.strip() for line in str(evidence or "").splitlines()]):
        if "no evidence yet" in line.casefold():
            continue
        candidate = normalize_answer(line, rules)
        if is_usable_answer(candidate):
            return candidate
    return ""


def finalize_for_submit(answer: str, rules: str) -> str:
    """Last cleanup before the wire: no control characters, sane length."""
    text = str(answer or "").replace("\x00", "").strip()
    if not text:
        return ""
    text = normalize_answer(text, rules) or text
    if len(text) > 16000:
        text = text[:16000]
    return text


def strict_final_value(reply: str, rules: str, known_tools: tuple[str, ...] = ()) -> str:
    """A loop-terminating answer: only an explicit final-answer label counts.

    The explorer's chat turns also contain plans and observations, so a bare
    sentence must never be mistaken for a finished answer.
    """
    labeled = extract_labeled_answer(reply)
    if not labeled:
        return ""
    value = normalize_answer(labeled, rules)
    return value if is_usable_answer(value, known_tools=known_tools) else ""


def rejection_reason(text: str, known_tools: tuple[str, ...] = ()) -> str:
    """Why a model reply is not a usable answer value, for a corrective retry."""
    value = str(text or "").strip()
    if not value:
        return "the reply was empty"
    if looks_like_tool_markup(value):
        return "the reply contained tool-call markup instead of an answer"
    if looks_like_tool_name(value, known_tools):
        return "the reply was a tool name, not an answer"
    if looks_like_payload_uri(value):
        return "the reply was an asset URI, not a text answer"
    if looks_like_refusal(value):
        return "the reply declined or said the material was missing instead of answering"
    if value.casefold() in {"unknown", "none", "n/a", "null", "undefined"}:
        return "the reply gave no concrete answer"
    control = sum(1 for char in value if ord(char) < 32 and char not in "\n\r\t")
    if control and control / max(1, len(value)) > 0.05:
        return "the reply was garbled binary text, not an answer"
    if len(value) > 2000:
        return "the reply was far longer than an answer value"
    return "the reply did not contain a usable answer value"


def answer_value_from_reply(
    reply: str,
    rules: str,
    *,
    known_tools: tuple[str, ...] = (),
) -> str:
    """Expose one deterministic reply-to-value conversion for the callers."""
    value = extract_labeled_answer(reply) or extract_json_answer(reply) or strip_wrappers(reply)
    value = normalize_answer(value, rules)
    return value if is_usable_answer(value, known_tools=known_tools) else ""
