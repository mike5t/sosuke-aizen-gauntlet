"""LLM-driven exploration loop for an unfamiliar MCP server.

The loop is deliberately stateless per round: every turn rebuilds a context
from the discovered catalog, the challenge payload, and everything the tools
have returned so far. That keeps a weak model focused, makes the transcript
bounded, and means an early bad call cannot poison the rest of the run.

Control flow (all of it schema-driven, none of it tool-name-driven):

1. ``bootstrap`` calls the most plausible task-payload tool.
2. ``cover_required_tools`` deterministically exercises every tool the
   challenge declares mandatory, inventing arguments from the JSON schema
   when prose is missing, and expanding per-identifier tools over the
   identifiers a previous result revealed.
3. ``explore`` runs the LLM tool-calling round loop, where the model picks the
   next tool and arguments from the live catalog, and every observation is fed
   back into the next decision.
4. ``answer`` asks for the exact value, cross-checks with an independent blind
   solve, and resolves a disagreement before the answer is handed back.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from arena_clients import McpArenaClient
from base_strategy import ChallengeContext
from catalog import ToolCatalog, flatten_text, render_value

import answers
from my_strategy import MyStrategy


# ---------------------------------------------------------------------------
# Small data carriers
# ---------------------------------------------------------------------------


@dataclass
class Observation:
    """One tool call and what came back."""

    index: int
    tool: str
    arguments: dict[str, Any]
    result: Any = None
    error: str = ""
    elapsed_s: float = 0.0
    cached: bool = False
    held: bool = False
    repaired: bool = False
    repair_fields: list[str] = field(default_factory=list)
    first_error: str = ""

    @property
    def ok(self) -> bool:
        return not self.error

    def signature(self) -> str:
        return f"{self.tool}({json.dumps(self.arguments, sort_keys=True, default=str)})"

    def rendered(self, limit: int = 2400) -> str:
        header = f"[{self.index}] {self.tool} {json.dumps(self.arguments, sort_keys=True, default=str)}"
        if self.error:
            body = f"ERROR: {self.error}"
        else:
            body = render_value(self.result, max_chars=limit)
        suffix = f" ({self.elapsed_s:.1f}s)"
        if self.cached:
            suffix += " (cached)"
        if self.repaired:
            suffix += " (recovered from schema mismatch: " + ", ".join(self.repair_fields) + ")"
        return f"{header}{suffix} -> {body}"

    def as_evidence(self) -> str:
        if self.error:
            return f"{self.tool} failed: {self.error}"
        text = flatten_text(self.result, max_chars=1800)
        if not text:
            text = render_value(self.result, max_chars=1800)
        return f"{self.tool}: {text}"


@dataclass
class Usage:
    """Token accounting across every proxy call in the run."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    requests: int = 0
    first_token_ms: int = 0

    def add(self, usage: Any, elapsed_ms: int) -> None:
        self.requests += 1
        if self.first_token_ms <= 0:
            self.first_token_ms = elapsed_ms
        if usage is None:
            return
        prompt = _int(getattr(usage, "prompt_tokens", 0))
        completion = _int(getattr(usage, "completion_tokens", 0))
        total = _int(getattr(usage, "total_tokens", 0)) or (prompt + completion)
        self.prompt_tokens += prompt
        self.completion_tokens += completion
        self.total_tokens += total

    def as_metrics(self) -> dict[str, Any]:
        return {
            "prompt_tokens": str(self.prompt_tokens),
            "completion_tokens": str(self.completion_tokens),
            "total_tokens": str(self.total_tokens),
        }


@dataclass
class ToolCall:
    """One function call requested by the model."""

    name: str
    arguments: dict[str, Any]
    call_id: str = ""
    parse_error: str = ""


@dataclass
class Reply:
    """One model reply, normalized for the loop."""

    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str = ""
    model: str = ""
    elapsed_ms: int = 0
    usage: Any = None
    error: str = ""
    fatal: bool = False


def _int(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------
# Clock
# ---------------------------------------------------------------------------


class ArenaClock:
    """Remaining time, anchored on the arena's own clock when one is exposed.

    The server's time tool is authoritative but costs a round trip, so the
    value is synced on the way in and then extrapolated locally. The wall
    clock is monotonic, so a slow call can never make the agent think it has
    more time than it does.
    """

    def __init__(
        self,
        max_time_s: float,
        *,
        sync: Callable[[], Any] | None = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.max_time_s = float(max_time_s or 0.0)
        self._clock = clock
        self._started = clock()
        self._deadline = self._started + self.max_time_s if self.max_time_s > 0 else 0.0
        self._sync = sync
        self.last_sync_s = 0.0

    async def sync(self) -> float:
        """Ask the server how long is left; fall back to the local estimate."""
        if self._sync is not None:
            try:
                value = self._sync()
                if asyncio.iscoroutine(value):
                    value = await asyncio.wait_for(value, timeout=8.0)
                remaining = _remaining_from(value)
                if remaining is not None:
                    self._deadline = self._clock() + max(0.0, remaining)
                    self.last_sync_s = self._clock()
            except Exception:
                pass
        return self.remaining()

    def remaining(self) -> float:
        if self._deadline <= 0:
            return float("inf")
        return max(0.0, self._deadline - self._clock())

    def elapsed(self) -> float:
        return max(0.0, self._clock() - self._started)


def _remaining_from(value: Any) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, dict):
        return None
    for key, item in value.items():
        if "remain" in str(key).casefold() and isinstance(item, (int, float)):
            return float(item)
    return None


# ---------------------------------------------------------------------------
# Payload interpretation
# ---------------------------------------------------------------------------

_DESCRIPTION_KEYS = (
    "description", "question", "task", "statement", "challenge_text", "challenge_description",
    "scenario", "brief", "problem",
)
_RULE_KEYS = (
    "rules", "output_format", "answer_format", "format", "instructions", "submission_format",
    "response_format", "requirements",
)
_REQUIRED_KEYS = ("required_tools", "must_call_tools", "mandatory_tools", "tools_required")
_CLUE_KEYS = ("clues", "hints", "evidence", "facts")
_PROMPT_KEYS = ("prompt", "edit_prompt", "image_prompt", "instruction")
_NOTES_KEYS = ("reference_notes", "notes", "guidance", "constraints")
_IMAGE_KEYS = ("input_image_uri", "source_image_uri", "image_uri", "image_url", "input_image")
_DIFFICULTY_KEYS = ("difficulty", "level", "tier")
_MAX_TIME_KEYS = ("max_time_s", "time_limit_s", "time_limit", "duration_s", "seconds_limit")


def _walk(node: Any, depth: int = 0):
    """Yield every ``(key, value)`` pair in a nested payload."""
    if depth > 6:
        return
    if isinstance(node, dict):
        for key, value in node.items():
            yield str(key), value
            yield from _walk(value, depth + 1)
    elif isinstance(node, list):
        for item in node[:50]:
            yield from _walk(item, depth + 1)


def _first_text(payload: Any, keys: tuple[str, ...]) -> str:
    """Longest matching string, preferring the payload's own top-level fields."""
    for scope in (_direct_items(payload), _walk(payload)):
        best = ""
        for key, value in scope:
            if key.casefold() not in keys:
                continue
            if isinstance(value, str) and value.strip() and len(value.strip()) > len(best):
                best = value.strip()
        if best:
            return best
    return ""


def _direct_items(payload: Any) -> list[tuple[str, Any]]:
    if not isinstance(payload, dict):
        return []
    return [(str(key), value) for key, value in payload.items()]


def _texts(payload: Any, keys: tuple[str, ...], *, limit: int = 40) -> list[str]:
    for scope in (_direct_items(payload), _walk(payload)):
        for key, value in scope:
            if key.casefold() not in keys:
                continue
            collected = _string_list(value, limit=limit)
            if collected:
                return collected
    return []


def _string_list(value: Any, *, limit: int = 40) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if not isinstance(value, (list, tuple)):
        return []
    collected: list[str] = []
    for item in value:
        if isinstance(item, str) and item.strip():
            collected.append(item.strip())
        elif isinstance(item, dict):
            for candidate in ("text", "clue", "value", "description", "hint"):
                if isinstance(item.get(candidate), str) and item[candidate].strip():
                    collected.append(item[candidate].strip())
                    break
        if len(collected) >= limit:
            break
    return collected


def _numbers(payload: Any, keys: tuple[str, ...]) -> float | None:
    for scope in (_direct_items(payload), _walk(payload)):
        for key, value in scope:
            if key.casefold() not in keys:
                continue
            if isinstance(value, (int, float)):
                return float(value)
            if isinstance(value, str):
                try:
                    return float(value)
                except ValueError:
                    continue
    return None


def _required_names(payload: Any, catalog: ToolCatalog) -> list[str]:
    """Tool names the payload declares as mandatory, from any nested key."""
    found: list[str] = []
    for key, value in _walk(payload):
        lowered = key.casefold()
        if not any(token in lowered for token in ("required", "must_call", "mandatory")):
            continue
        for name in _string_list(value, limit=40):
            if not name:
                continue
            if name in catalog or re.fullmatch(r"[A-Za-z0-9_.:-]{2,120}", name):
                if name not in found:
                    found.append(name)
    return found


def _payload_challenge_text(payload: Any) -> str:
    description = _first_text(payload, _DESCRIPTION_KEYS)
    rules = _first_text(payload, _RULE_KEYS)
    prompt = _first_text(payload, _PROMPT_KEYS)
    notes = _first_text(payload, _NOTES_KEYS)
    parts = [part for part in (description, prompt, notes) if part]
    if rules and rules not in parts:
        parts.append(rules)
    return "\n".join(dict.fromkeys(parts))


def _image_uri(payload: Any) -> str:
    for key, value in _walk(payload):
        if key.casefold() in _IMAGE_KEYS and isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _payload_rules(payload: Any) -> str:
    rules = _first_text(payload, _RULE_KEYS)
    notes = _first_text(payload, _NOTES_KEYS)
    if rules and notes and notes not in rules:
        return f"{rules}\n{notes}"
    return rules or notes


def _has_image_signal(payload: Any) -> bool:
    """True when a payload looks like an image task rather than a text task."""
    if _image_uri(payload):
        return True
    prompt = _first_text(payload, _PROMPT_KEYS)
    if prompt and "image" in prompt.casefold():
        return True
    kind = _first_text(payload, ("challenge_type", "type", "kind", "modality"))
    return "image" in kind.casefold()


def _challenge_score(payload: Any, catalog: ToolCatalog) -> int:
    """How much a payload looks like a task briefing rather than plain data."""
    if not isinstance(payload, dict):
        return 0
    score = 0
    if _first_text(payload, _DESCRIPTION_KEYS):
        score += 2
    if _first_text(payload, _RULE_KEYS):
        score += 2
    if _first_text(payload, _PROMPT_KEYS):
        score += 2
    if _texts(payload, _CLUE_KEYS):
        score += 1
    if _required_names(payload, catalog):
        score += 2
    if _image_uri(payload):
        score += 2
    return score


# ---------------------------------------------------------------------------
# LLM wrapper
# ---------------------------------------------------------------------------


class LLM:
    """Thin synchronous wrapper over the OpenAI-compatible proxy."""

    def __init__(self, client: Any, agent_id: str) -> None:
        self._client = client
        self._agent_id = agent_id
        self.usage = Usage()

    def chat(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float = 0.0,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | None = None,
        timeout: float = 60.0,
    ) -> Reply:
        started = time.monotonic()
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "max_tokens": int(max_tokens),
            "temperature": float(temperature),
            "timeout": float(timeout),
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = tool_choice or "auto"
        try:
            response = self._client.chat.completions.create(**kwargs)
        except Exception as exc:  # proxy, provider, or timeout failure
            elapsed = int((time.monotonic() - started) * 1000)
            message = f"{type(exc).__name__}: {exc}"
            return Reply(
                model=model,
                elapsed_ms=elapsed,
                error=message,
                fatal=_is_fatal_model_error(message),
            )

        elapsed = int((time.monotonic() - started) * 1000)
        choice = response.choices[0] if response.choices else None
        message = getattr(choice, "message", None)
        content = str(getattr(message, "content", "") or "")
        reply = Reply(
            content=content,
            finish_reason=str(getattr(choice, "finish_reason", "") or ""),
            model=str(getattr(response, "model", model) or model),
            elapsed_ms=elapsed,
            usage=getattr(response, "usage", None),
        )
        for call in getattr(message, "tool_calls", None) or []:
            function = getattr(call, "function", None)
            name = str(getattr(function, "name", "") or "").strip()
            raw_arguments = getattr(function, "arguments", "") or "{}"
            arguments, parse_error = _parse_arguments(raw_arguments)
            reply.tool_calls.append(
                ToolCall(
                    name=name,
                    arguments=arguments,
                    call_id=str(getattr(call, "id", "") or ""),
                    parse_error=parse_error,
                )
            )
        self.usage.add(reply.usage, elapsed)
        return reply


def _parse_arguments(raw: Any) -> tuple[dict[str, Any], str]:
    if isinstance(raw, dict):
        return dict(raw), ""
    text = str(raw or "").strip()
    if not text:
        return {}, ""
    for candidate in (text, text.strip("`"), _first_json_object(text)):
        if not candidate:
            continue
        try:
            parsed = json.loads(candidate)
        except (TypeError, json.JSONDecodeError):
            continue
        if isinstance(parsed, dict):
            return parsed, ""
        if isinstance(parsed, list) and len(parsed) == 1 and isinstance(parsed[0], dict):
            return dict(parsed[0]), ""
    return {}, f"could not parse tool arguments as JSON: {text[:200]}"


def _first_json_object(text: str) -> str:
    start = text.find("{")
    if start < 0:
        return ""
    depth = 0
    for index in range(start, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return text[start : index + 1]
    return ""


# ---------------------------------------------------------------------------
# Explorer
# ---------------------------------------------------------------------------

_ID_PROP_SUFFIXES = ("_id", "_ids", "id")

_MISSING = object()

# Identity properties are filled by the runtime, never by the model. The
# schema often marks agent_id optional (it has a "default"), and a server that
# receives the default instead of this agent's id rejects every call.
_IDENTITY_PROPS = {"agent_id", "agentid"}

# Properties that carry the final value a submit tool should receive.
_ANSWER_PROP_NAMES = {
    "answer", "final_answer", "edited_image", "image", "image_uri", "output",
    "result", "response", "solution", "value",
}

# Tools the model may call even though the server never advertised them,
# because evidence can reveal hidden capabilities.
_ESCAPE_TOOL = "call_unlisted_tool"


class Explorer:
    """Discovery, chained tool use, and answer production for one challenge."""

    def __init__(
        self,
        *,
        mcp: McpArenaClient,
        catalog: ToolCatalog,
        strategy: MyStrategy,
        llm: LLM,
        clock: ArenaClock,
        agent_id: str,
        ranked_models: list[str],
        think: Callable[[str], Any] | None = None,
        log: Callable[[str], None] | None = None,
        image_assignment: bool = False,
    ) -> None:
        self.mcp = mcp
        self.catalog = catalog
        self.strategy = strategy
        self.llm = llm
        self.clock = clock
        self.agent_id = agent_id
        self.image_assignment = image_assignment
        self.ranked_models = [model for model in ranked_models if model]
        self._think = think or (lambda _text: None)
        self._log = log or (lambda _text: print(_text, flush=True))

        self.observations: list[Observation] = []
        self._cache: dict[str, Observation] = {}
        self._called: set[str] = set()
        self._succeeded: set[str] = set()
        self._failures: dict[str, int] = {}
        self._unknown_calls = 0
        self._unknown_tried: set[str] = set()
        self._attempted: set[str] = set()
        self._schema_liars: set[str] = set()
        self._schema_repairs: set[str] = set()
        self._swept = False
        self._next_index = 1
        self._id_sources: dict[str, str] = {}

        self.challenge: dict[str, Any] = {}
        self.challenge_tool = ""
        self.required_tools: list[str] = []
        self.id_pool: list[str] = []
        self.scalars: dict[str, str] = {}
        self.clues: list[str] = []
        self.description = ""
        self.rules = ""
        self.difficulty = "unknown"
        self.challenge_type = ""
        self.max_time_s = 0
        self.image_uri = ""
        self.candidate = ""
        self.timed_out = False
        self.rounds = 0
        self.models_used: list[str] = []
        self._challenge_score = 0
        self._deferred_tools: set[str] = set()
        self._catalog_dirty = False
        self.aliased_tools = False
        self.json_protocol = False
        self._alias_to_real: dict[str, str] = {}
        self._real_to_alias: dict[str, str] = {}

    # ---- bookkeeping -----------------------------------------------------
    def _model(self, stage: str) -> str:
        model = self.strategy.pick_model(stage, self.ranked_models, self.context())
        if model and model not in self.models_used:
            self.models_used.append(model)
        return model

    def context(self) -> ChallengeContext:
        return ChallengeContext(
            challenge_type=self.challenge_type or "text",
            difficulty=self.difficulty,
            challenge_text=self.description,
            description=self.description,
            rules=self.rules,
            clues=list(self.clues),
            time_remaining_s=self.clock.remaining(),
            max_time_s=int(self.max_time_s or 0),
            available_models=list(self.ranked_models),
            tools_used=sorted(self._called),
            tokens_used=self.llm.usage.total_tokens,
            required_tools=list(self.required_tools),
            image_url=self.image_uri or None,
        )

    def _bag(self) -> dict[str, Any]:
        """Known values for schema-driven argument synthesis."""
        return {
            "agent_id": self.agent_id,
            "id_pool": list(self.id_pool),
            "scalars": dict(self.scalars),
            "clues": list(self.clues),
            "description": self.description,
            "rules": self.rules,
            "prompt": self.description,
            "question": self.description,
            "query": self.description,
            "text": self.description,
            "image_uri": self.image_uri,
            "url": self.image_uri,
            "thought": "Explorer progress update.",
            "answer": "",
        }

    def _remember_observation(self, observation: Observation) -> None:
        self.observations.append(observation)
        if observation.held:
            # A guarded submission attempt is guidance, not a tool call.
            self.observations.append(observation)
            return
        self._called.add(observation.tool)
        if not observation.ok:
            self._failures[observation.tool] = self._failures.get(observation.tool, 0) + 1
            return
        self._succeeded.add(observation.tool)
        if any(name not in self.catalog for name in self.required_tools):
            # A required capability is not in the catalog yet. The call that
            # was just made may have registered it, so re-read the tool list
            # before the next decision.
            self._catalog_dirty = True
        self._harvest(observation.result, tool=observation.tool)
        # A challenge can be nested behind an ordinary-looking function: if a
        # result is more task-like than anything seen so far, adopt it. When
        # the assignment is an image challenge, only an image-shaped payload
        # can be the task; a text payload found on the way is just evidence.
        score = _challenge_score(observation.result, self.catalog)
        if self.image_assignment and not _has_image_signal(observation.result):
            score = 0
        if self.has_challenge_payload:
            # A payload for the other modality is evidence, not this run's task.
            current_image = _has_image_signal(self.challenge)
            if current_image != _has_image_signal(observation.result):
                score = 0
        if score >= 4 and score > self._challenge_score:
            self._ingest_payload(observation.result)
            self.challenge_tool = observation.tool
            self._challenge_score = score
            self._log(
                f"   Task payload discovered via {observation.tool} "
                f"({len(self.required_tools)} required tools)"
            )

    def _harvest(self, result: Any, *, tool: str = "", with_requirements: bool = False) -> None:
        """Collect identifiers and clue text any result happens to reveal.

        ``with_requirements`` is reserved for the payload that was actually
        adopted as this run's task. A text task discovered while the assignment
        is an image challenge must not impose its required tools on the image
        run.
        """
        clue_tool = bool({"clue", "clues", "hint", "hints"} & set(_tool_tokens(tool)))
        for key, value in _walk(result):
            lowered = key.casefold()
            if with_requirements and lowered in _REQUIRED_KEYS:
                for name in _string_list(value):
                    if name and name not in self.required_tools:
                        self.required_tools.append(name)
            if lowered in _CLUE_KEYS:
                for text in _string_list(value):
                    if text and text not in self.clues:
                        self.clues.append(text)
            elif (
                clue_tool
                and lowered in {"text", "content", "clue", "value"}
                and isinstance(value, str)
                and value.strip()
                and len(value) <= 2000
                and value.strip() not in self.clues
            ):
                self.clues.append(value.strip())
            if isinstance(value, (list, tuple)) and any(
                token in lowered for token in ("tool", "capab", "function", "method")
            ):
                for item in value:
                    if isinstance(item, str) and item not in self.catalog:
                        # A tool list revealed a capability the handshake did
                        # not advertise; refresh the catalog before the next
                        # decision so the model can actually call it.
                        self._catalog_dirty = True
        for value in _identifier_values(result):
            if value not in self.id_pool and len(self.id_pool) < 24:
                self.id_pool.append(value)
                self._id_sources[value] = tool
        for scalar_key, scalar_value in _named_scalars(result):
            # Latest wins: a gated call that finally succeeds usually returns
            # the handle to use, replacing whatever a rejected attempt named.
            self.scalars[scalar_key] = scalar_value

    def _identifiers_for(self, prop: str) -> list[str]:
        """Identifiers a tool property can plausibly consume.

        Scope by the property's stem first (``clue_id`` -> identifiers that
        mention "clue" or came from a clue tool). Only then fall back to the
        whole pool, and never to identifiers that came from the bootstrap
        payload itself: those are the challenge's own id, not a handle for
        another tool.
        """
        normalized = _normalize(prop)
        stem = normalized
        for suffix in ("_ids", "_id"):
            if normalized.endswith(suffix):
                stem = normalized[: -len(suffix)]
                break
        stem = stem.strip("_")
        if stem and stem not in {"id", "ids"}:
            scoped = [
                identifier
                for identifier in self.id_pool
                if stem in identifier.casefold()
                or stem in self._id_sources.get(identifier, "").casefold()
            ]
            if scoped:
                return scoped
        return [
            identifier
            for identifier in self.id_pool
            if self._id_sources.get(identifier, "") != self.challenge_tool
        ]

    def _ingest_payload(self, payload: dict[str, Any], *, image: bool = False) -> None:
        # A tool can return several task records. Taking the first task-shaped
        # subtree, or merging fields across all of them, answers the wrong
        # task; pick the live one explicitly.
        selected = _select_task_record(payload)
        if selected is not None:
            payload = selected
        replacing = self.has_challenge_payload
        self.challenge = payload if isinstance(payload, dict) else {"value": payload}
        self.description = _payload_challenge_text(self.challenge)
        self.rules = _payload_rules(self.challenge)
        if replacing:
            # A different task means different requirements and evidence; the
            # old challenge's tools must not leak into the new one.
            self.required_tools.clear()
            self.clues = []
            self._deferred_tools.clear()
        self.clues = _texts(self.challenge, _CLUE_KEYS) or self.clues
        self.difficulty = _first_text(self.challenge, _DIFFICULTY_KEYS) or self.difficulty
        self.challenge_type = _first_text(
            self.challenge, ("challenge_type", "type", "kind", "modality")
        ) or ("image" if image else "text")
        self.max_time_s = _numbers(self.challenge, _MAX_TIME_KEYS) or self.max_time_s
        self.image_uri = _image_uri(self.challenge) or ("" if replacing else self.image_uri)
        found_required = _required_names(self.challenge, self.catalog)
        for name in found_required:
            if name not in self.required_tools:
                self.required_tools.append(name)
        self._harvest(self.challenge, with_requirements=True)
        self._challenge_score = max(self._challenge_score, _challenge_score(self.challenge, self.catalog))

    # ---- tool execution --------------------------------------------------
    def _canonical(self, name: str, arguments: dict[str, Any]) -> str:
        return f"{name}|{json.dumps(arguments, sort_keys=True, default=str)}"

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float = 30.0,
        allow_unlisted: bool = False,
        quiet: bool = False,
    ) -> Observation:
        """Execute one MCP tool, cache it, and record the observation."""
        raw_arguments = dict(arguments or {})
        spec = self.catalog.get(name)
        unlisted = spec is None
        if unlisted and (not allow_unlisted or name in self._unknown_tried):
            observation = Observation(
                index=self._next_index,
                tool=name,
                arguments=raw_arguments,
                error=(
                    f"tool {name!r} is not in the discovered catalog"
                    if not allow_unlisted
                    else f"tool {name!r} was already probed and is not available"
                ),
            )
            self._next_index += 1
            self._remember_observation(observation)
            return observation

        if spec is not None and name not in self._schema_liars:
            cleaned = self.catalog.sanitize_arguments(name, raw_arguments)
        else:
            # A tool whose advertised schema already lied once gets its raw
            # arguments: the server's real signature is the authority.
            cleaned = dict(raw_arguments)
        if spec is not None:
            for prop in spec.properties:
                if _normalize(prop) in _IDENTITY_PROPS:
                    # Our own identity always wins over a model-supplied value.
                    cleaned[prop] = self.agent_id
        missing = self.catalog.missing_required(name, cleaned) if spec else []
        if missing:
            filled, still_missing = self.catalog.synthesize_arguments(name, {**self._bag(), **cleaned})
            cleaned = {**filled, **cleaned}
            missing = still_missing
        if missing:
            observation = Observation(
                index=self._next_index,
                tool=name,
                arguments=cleaned,
                error=f"missing required argument(s): {', '.join(missing)}",
            )
            self._next_index += 1
            self._remember_observation(observation)
            return observation

        key = self._canonical(name, cleaned)
        cached = self._cache.get(key)
        if cached is not None:
            replay = Observation(
                index=self._next_index,
                tool=cached.tool,
                arguments=cached.arguments,
                result=cached.result,
                error=cached.error,
                elapsed_s=0.0,
                cached=True,
            )
            self._next_index += 1
            self._remember_observation(replay)
            return replay

        started = time.monotonic()
        error = ""
        result: Any = None
        self._attempted.add(key)
        if unlisted:
            self._unknown_tried.add(name)
            self._unknown_calls += 1
        try:
            result = await asyncio.wait_for(
                self.mcp.call_tool(name, cleaned),
                timeout=max(4.0, float(timeout)),
            )
        except asyncio.TimeoutError:
            error = f"timed out after {timeout:.0f}s"
        except Exception as exc:  # transport or server-side failure
            error = f"{type(exc).__name__}: {exc}"
        if not error:
            error = _tool_error(result)
        repaired_fields: list[str] = []
        first_error = ""
        if error and _is_schema_error(error):
            self._schema_liars.add(name)
            repaired_fields = _missing_fields(error)
            first_error = error
            repaired = await self._repair_schema_liar(name, cleaned, error)
            if repaired is not None:
                result, error = repaired
        observation = Observation(
            index=self._next_index,
            tool=name,
            arguments=cleaned,
            result=result,
            error=error,
            elapsed_s=time.monotonic() - started,
            repaired=bool(repaired_fields) and not error,
            repair_fields=repaired_fields if not error else [],
            first_error=first_error,
        )
        self._next_index += 1
        if not error:
            # Only a successful call is worth replaying. Caching a failure made
            # a probe loop look like progress and re-served a stale error.
            self._cache[key] = observation
        self._remember_observation(observation)
        if not quiet:
            self._log(f"   {observation.rendered(limit=320)}")
        return observation

    def _was_called(self, name: str) -> bool:
        return name in self._called

    @property
    def has_challenge_payload(self) -> bool:
        return self._challenge_score >= 4

    async def refresh_catalog(self) -> list[str]:
        """Re-read the server's tool list and adopt newly advertised tools."""
        self._catalog_dirty = False
        try:
            defs = await asyncio.wait_for(self.mcp.list_tool_defs(), timeout=15.0)
        except Exception as exc:
            self._log(f"   Catalog refresh failed: {type(exc).__name__}")
            return []
        refreshed = ToolCatalog(defs)
        added = [name for name in refreshed.names if name not in self.catalog]
        removed = [name for name in self.catalog.names if name not in refreshed]
        if added or removed:
            self.catalog = refreshed
            if self.aliased_tools:
                self._alias_to_real.clear()
                self._real_to_alias.clear()
                self._build_alias_map()
            if added:
                self._log(f"   Catalog refresh added: {', '.join(added)}")
            if removed:
                self._log(f"   Catalog refresh removed: {', '.join(removed)}")
        return added

    def missing_required(self) -> list[str]:
        return [name for name in self.required_tools if not self._was_called(name)]

    def uncovered_required(self) -> list[str]:
        """Required tools that have not had one successful call.

        ``missing_required`` tracks attempted calls, which keeps retries
        bounded. This tracks *success*, which is what decides whether the value
        space still needs searching: a required tool that failed under its
        defaults is uncovered even though it was called.
        """
        return [name for name in self.required_tools if name not in self._succeeded]

    # ---- stage 1: bootstrap ---------------------------------------------
    async def bootstrap(self, *, image: bool) -> Observation | None:
        """Call the most plausible task-payload tool and ingest its payload."""
        candidates = self.catalog.challenge_candidates(image=image)
        parameterless: list[str] = []
        requires_args: list[str] = []
        # A tool that needs no arguments (or only the agent id) is the safest
        # first call; a tool with an unknown prerequisite waits for evidence.
        for name in candidates:
            spec = self.catalog.get(name)
            if spec is None:
                continue
            if set(p.lower() for p in spec.required) <= {"agent_id", "agentid", "session_id"}:
                parameterless.append(name)
            else:
                requires_args.append(name)
        ordered = parameterless + requires_args
        if not ordered:
            # Nothing looks like a task tool: probe the catalog in order, which
            # is still discovery rather than a hardcoded assumption.
            ordered = [name for name in self.catalog.names if self._is_parameterless(name)][:3]
        if not ordered:
            return None

        observation: Observation | None = None
        attempted = 0
        for name in ordered:
            if attempted >= 3 or self.clock.remaining() < self.strategy.min_useful_step_s * 2:
                break
            # Never call a tool whose required arguments cannot be filled yet:
            # an image describer before the source image exists, for example.
            arguments, missing = self.catalog.synthesize_arguments(name, self._bag())
            if missing:
                continue
            attempted += 1
            observation = await self.call_tool(name, arguments)
            # Accept the next result only if it is a task briefing. Plain data
            # from a parameterless tool is evidence, not the challenge.
            if observation.ok and _challenge_score(observation.result, self.catalog) >= 4:
                if self.image_assignment and not _has_image_signal(observation.result):
                    continue
                self.challenge_tool = name
                self._ingest_payload(observation.result, image=image)
                break
        if self.challenge_tool:
            # Prefer the clock from the challenge, then re-anchor on the server.
            if self.max_time_s:
                self.clock.max_time_s = max(self.clock.max_time_s, self.max_time_s)
            await self.clock.sync()
        else:
            # The obvious tools held data, not a task: probe the rest.
            await self.hunt_for_payload()
        await self._seed_server_map()
        return observation

    async def _seed_server_map(self) -> None:
        """Call a tool-enumeration tool once, when the server offers one.

        A server that can list its own tools may reveal more than the initial
        handshake did, which is the cheapest possible exploration win.
        """
        candidates = self.catalog.tools_list_candidates()
        if not candidates:
            return
        if self.clock.remaining() < self.strategy.min_useful_step_s:
            return
        await self.call_tool(candidates[0], {}, quiet=True)

    def _is_parameterless(self, name: str) -> bool:
        spec = self.catalog.get(name)
        if spec is None:
            return False
        return set(p.lower() for p in spec.required) <= {"agent_id", "agentid", "session_id"}

    # ---- stage 2: mandatory coverage ------------------------------------
    async def cover_required_tools(self, *, call_limit: int = 12) -> list[str]:
        """Exercise every declared-required tool, schema-first.

        Order matters: a tool that lists identifiers runs before the tools that
        consume those identifiers, which is the chain the challenge implies.
        """
        if not self.required_tools:
            return []
        if self._catalog_dirty or any(
            name not in self.catalog for name in self.required_tools
        ):
            await self.refresh_catalog()
        calls = 0
        self._log(f"   Required tools: {', '.join(self.required_tools)}")
        # Answer-submission tools are required, but calling one before the
        # answer exists would submit a guess. They are deferred until the
        # answer is final (see submit_answer_via_tool).
        self._deferred_tools = {
            name for name in self.required_tools if self._is_submit_like(name)
        }
        if self._deferred_tools:
            self._log(f"   Deferred until the answer is final: {', '.join(sorted(self._deferred_tools))}")
        active = [name for name in self.required_tools if name not in self._deferred_tools]

        # Prime identifier lists first (a "*_ids" style tool or a clue lister).
        for name in active:
            if calls >= call_limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            spec = self.catalog.get(name)
            if spec is None or self._was_called(name):
                continue
            takes_ids = any(_is_id_prop(prop) for prop in spec.required)
            if takes_ids:
                continue
            arguments, missing = self.catalog.synthesize_arguments(name, self._bag())
            if missing:
                continue
            await self.call_tool(name, arguments, quiet=True)
            calls += 1

        # Expand identifier-consuming tools over every identifier discovered.
        for name in active:
            spec = self.catalog.get(name)
            if spec is None:
                continue
            id_props = [prop for prop in spec.required if _is_id_prop(prop)]
            if not id_props:
                continue
            identifiers = self._identifiers_for(id_props[0])
            for identifier in identifiers[:10]:
                if calls >= call_limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                    break
                arguments, missing = self.catalog.synthesize_arguments(
                    name, {**self._bag(), id_props[0]: identifier}
                )
                if missing:
                    break
                await self.call_tool(name, arguments, quiet=True)
                calls += 1

        # Anything still untouched gets a planner round trip for its arguments.
        pending = [
            name
            for name in active
            if not self._was_called(name) and name in self.catalog
        ]
        if pending and self.clock.remaining() > self.strategy.min_useful_step_s * 2:
            planned = await self._plan_arguments(pending)
            for name, arguments in planned.items():
                if calls >= call_limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                    break
                await self.call_tool(name, arguments, quiet=True)
                calls += 1

        # Required tools the server refused keep their failure on record; one
        # bounded retry with a minimal argument set covers shape mismatches.
        for name in active:
            if self._was_called(name) or name not in self.catalog:
                continue
            if calls >= call_limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            await self.call_tool(name, self._minimal_arguments(name), quiet=True)
            calls += 1

        missing = self.missing_required()
        deferred_missing = [name for name in missing if name in self._deferred_tools]
        uncovered = [name for name in self.uncovered_required() if name not in self._deferred_tools]
        if uncovered and not self._swept and self.clock.remaining() > self.strategy.min_useful_step_s * 2:
            # A required tool that failed under its defaults may expose a
            # working path under another declared value (a gate, a mode, a
            # scope), or only under a pair of values. Both searches are
            # deterministic and bounded.
            self._log(f"   Uncovered required tools ({', '.join(uncovered)}); sweeping value space")
            await self.sweep_enums(limit=6)
            if self._catalog_dirty or any(
                name not in self.catalog for name in self.required_tools
            ):
                await self.refresh_catalog()
            await self.probe_combinations(uncovered, limit=8)
            # A sweep that just produced a new handle (a key, a nonce, a blob)
            # makes earlier calls with the wrong handle stale. Re-run the tools
            # whose arguments come from those names.
            await self.retry_scalar_dependents(limit=3)
            for name in self.uncovered_required():
                if calls >= call_limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                    break
                if name not in self.catalog or self._is_submit_like(name):
                    continue
                arguments, missing_args = self.catalog.synthesize_arguments(name, self._bag())
                if missing_args:
                    continue
                await self.call_tool(name, arguments, quiet=True)
                calls += 1
            missing = self.missing_required()
            uncovered = [name for name in self.uncovered_required() if name not in self._deferred_tools]
        if self.clues:
            covered = len(self.required_tools) - len(missing)
            self._think(
                f"Gathered {len(self.clues)} clues; required coverage {covered}/{len(self.required_tools)}"
            )
        if deferred_missing:
            self._log(f"   Deferred for the answer stage: {', '.join(deferred_missing)}")
        return missing

    async def sweep_enums(self, *, limit: int = 6) -> list[str]:
        """Call tools across their declared value space, not just defaults.

        A server can hide a capability behind one enum value (a manifest tool
        whose ``all`` mode reveals a tool nobody advertised) or behind a nested
        enum (a catalog filter whose ``image`` mode reveals the image task).
        When exploration is lost, varying declared values is a deterministic
        breadth move that does not depend on the model guessing.
        """
        tried: list[str] = []
        self._swept = True
        if self.clock.remaining() < self.strategy.min_useful_step_s * 2:
            return tried
        for name in self.catalog.names:
            if len(tried) >= limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            spec = self.catalog.get(name)
            if spec is None or not spec.properties:
                continue
            probes = list(_enum_probes(spec.input_schema))
            if not probes:
                continue
            base, missing = self.catalog.synthesize_arguments(name, self._bag())
            if missing:
                continue
            for path, value in probes:
                if len(tried) >= limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                    break
                arguments = _deep_merge(base, _nest(path, value))
                probe = self.catalog.sanitize_arguments(name, arguments)
                for identity_prop in spec.properties:
                    if _normalize(identity_prop) in _IDENTITY_PROPS:
                        probe[identity_prop] = self.agent_id
                if self._canonical(name, probe) in self._attempted:
                    continue
                observation = await self.call_tool(name, arguments, quiet=True)
                label = ".".join(path)
                tried.append(f"{name}({label}={value!r})")
                self._log(
                    f"   Value-space sweep: {name}({label}={value!r}) -> "
                    f"{'ok' if observation.ok else observation.error[:100]}"
                )
        return tried

    async def hunt_for_payload(self, *, call_limit: int = 5) -> bool:
        """Probe uncalled tools for the task briefing, schema-first.

        Called when the conventional task tools did not carry the payload. A
        challenge can sit behind an ordinary-looking function (a catalog query,
        a status call), so uncalled tools are exercised with synthesized
        arguments, cheapest and most task-shaped first.
        """
        if self.has_challenge_payload or not self.catalog:
            return self.has_challenge_payload
        # Task-shaped names first, then everything else in catalog order.
        hints = ("task", "challenge", "catalog", "brief", "query", "describe", "status", "list")
        ranked = self.catalog.rank(hints)
        ordered = ranked + [name for name in self.catalog.names if name not in set(ranked)]
        calls = 0
        for name in ordered:
            if calls >= call_limit or self.has_challenge_payload:
                break
            if self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            spec = self.catalog.get(name)
            if spec is None or self._was_called(name) or self._is_submit_like(name):
                continue
            arguments, missing = self.catalog.synthesize_arguments(name, self._bag())
            if missing:
                continue
            await self.call_tool(name, arguments, quiet=True)
            calls += 1
        if not self.has_challenge_payload:
            # Follow handles the first pass revealed: a tool that needs an id
            # is the natural next hop when a list just handed us ids.
            await self._hunt_by_identifiers(limit=4)
        if self.has_challenge_payload:
            self._log(f"   Task payload located via {self.challenge_tool}")
        else:
            # Deterministic breadth move before handing the problem back to the
            # model: vary the declared value space of every safe tool.
            await self.sweep_enums(limit=6)
            if self.has_challenge_payload:
                self._log(f"   Task payload located via {self.challenge_tool}")
        return self.has_challenge_payload

    async def _hunt_by_identifiers(self, *, limit: int = 4) -> None:
        """Call uncalled id-consuming tools with identifiers already revealed."""
        calls = 0
        for name in self.catalog.names:
            if calls >= limit or self.has_challenge_payload:
                break
            if self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            if self._was_called(name) or self._is_submit_like(name):
                continue
            spec = self.catalog.get(name)
            if spec is None:
                continue
            id_props = [prop for prop in spec.required if _is_id_prop(prop)]
            if len(id_props) != 1:
                continue
            for identifier in self._identifiers_for(id_props[0])[:3]:
                if calls >= limit or self.has_challenge_payload:
                    break
                arguments, missing = self.catalog.synthesize_arguments(
                    name, {**self._bag(), id_props[0]: identifier}
                )
                if missing:
                    break
                await self.call_tool(name, arguments, quiet=True)
                calls += 1

    async def probe_combinations(self, tools: list[str], *, limit: int = 8) -> list[str]:
        """Try pairs of declared values for tools that stay uncovered.

        A capability can sit behind two arguments that must both be right (a
        scope and a slot, a mode and an index). Varying one value at a time
        never reaches it. The grid is taken from the schema's own enum and
        boolean values plus a small integer range, and it is bounded.
        """
        tried: list[str] = []
        for name in tools:
            if len(tried) >= limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            spec = self.catalog.get(name)
            if spec is None:
                continue
            enumerable = _enumerable_props(spec)
            if len(enumerable) < 2:
                continue
            (first_prop, first_values), (second_prop, second_values) = enumerable[0], enumerable[1]
            for first in first_values:
                for second in second_values:
                    if len(tried) >= limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                        break
                    arguments = {first_prop: first, second_prop: second}
                    probe = self.catalog.sanitize_arguments(name, arguments)
                    for identity_prop in spec.properties:
                        if _normalize(identity_prop) in _IDENTITY_PROPS:
                            probe[identity_prop] = self.agent_id
                    if self._canonical(name, probe) in self._attempted:
                        continue
                    observation = await self.call_tool(name, arguments, quiet=True)
                    tried.append(f"{name}({first_prop}={first!r},{second_prop}={second!r})")
                    self._log(
                        f"   Pair sweep: {name}({first_prop}={first!r}, {second_prop}={second!r}) -> "
                        f"{'ok' if observation.ok else observation.error[:90]}"
                    )
                    if observation.ok and self.has_challenge_payload:
                        break
        return tried

    async def _repair_schema_liar(
        self,
        name: str,
        arguments: dict[str, Any],
        error: str,
    ) -> tuple[Any, str] | None:
        """Retry once with the field names the server's validation error names.

        A tool can advertise one argument schema while validating another. The
        error text is the only truthful documentation in that case, so its
        missing-field names are filled from known handles or from the values
        already sent, positionally.
        """
        if name in self._schema_repairs:
            return None
        missing = _missing_fields(error)
        if not missing or self.clock.remaining() < self.strategy.min_useful_step_s:
            return None
        self._schema_repairs.add(name)
        pool = list(arguments.values())
        repaired = dict(arguments)
        for field in missing:
            normalized = _normalize(field)
            value = self.scalars.get(normalized)
            if value in (None, ""):
                value = self._bag().get(normalized)
            if value in (None, "") and pool:
                value = pool.pop(0)
            if value not in (None, ""):
                repaired[field] = value
        if not any(field in repaired for field in missing):
            return None
        self._log(
            f"   Schema mismatch on {name}; retrying with the fields the server named: "
            f"{', '.join(missing)}"
        )
        try:
            result = await asyncio.wait_for(
                self.mcp.call_tool(name, repaired),
                timeout=min(40.0, max(6.0, self.clock.remaining() - self.strategy.submit_reserve_s)),
            )
        except Exception as exc:
            return None, f"{type(exc).__name__}: {exc}"
        retry_error = _tool_error(result)
        self._log(
            f"   Repaired call {name} -> " + ("ok" if not retry_error else retry_error[:120])
        )
        return result, retry_error

    async def retry_scalar_dependents(self, *, limit: int = 3) -> list[str]:
        """Re-run tools whose arguments are named handles that just changed.

        A decoder called with a guessed key returns plausible bytes and looks
        successful. When the real key appears later, that call is stale; a
        call with the new arguments is not in the attempt cache, so it runs.
        """
        retried: list[str] = []
        scalar_names = set(self.scalars)
        if not scalar_names:
            return retried
        for name in self.required_tools:
            if len(retried) >= limit or self.clock.remaining() < self.strategy.min_useful_step_s:
                break
            if name not in self.catalog or self._is_submit_like(name):
                continue
            spec = self.catalog.require(name)
            required_names = {_normalize(prop) for prop in spec.required}
            if not (required_names & scalar_names):
                continue
            arguments, missing = self.catalog.synthesize_arguments(name, self._bag())
            if missing:
                continue
            probe = self.catalog.sanitize_arguments(name, arguments)
            for identity_prop in spec.properties:
                if _normalize(identity_prop) in _IDENTITY_PROPS:
                    probe[identity_prop] = self.agent_id
            if self._canonical(name, probe) in self._attempted:
                continue
            observation = await self.call_tool(name, arguments, quiet=True)
            retried.append(name)
            self._log(
                f"   Re-ran {name} with updated handles -> "
                f"{'ok' if observation.ok else observation.error[:90]}"
            )
        return retried

    def _is_submit_like(self, name: str) -> bool:
        """True when a tool exists to receive the final answer itself."""
        spec = self.catalog.get(name)
        if spec is None:
            return False
        tokens = set(_tool_tokens(name))
        if not (tokens & {"submit", "answer", "final", "finalize", "score", "send"}):
            return False
        declared = {_normalize(prop) for prop in spec.properties}
        return bool(declared & _ANSWER_PROP_NAMES)

    async def submit_answer_via_tool(self, answer: str) -> Observation | None:
        """Submit through a discovered answer tool when the server expects one.

        Required-tool coverage defers these so the first call carries a real
        answer. Arguments other than the answer are filled from named scalars
        and identifiers the exploration already revealed.
        """
        if not answer:
            return None
        candidates = [
            name
            for name in self.required_tools
            if self._is_submit_like(name) and not self._was_called(name)
        ]
        if not candidates:
            return None
        for name in candidates:
            spec = self.catalog.get(name)
            if spec is None:
                continue
            bag = {**self._bag(), "answer": answer, "text": answer}
            arguments, missing = self.catalog.synthesize_arguments(name, bag)
            non_answer_missing = [
                prop for prop in missing if _normalize(prop) not in _ANSWER_PROP_NAMES
            ]
            if non_answer_missing and self.clock.remaining() > self.strategy.min_useful_step_s * 2:
                planned = await self._plan_arguments([name])
                for key, value in planned.get(name, {}).items():
                    if _normalize(key) not in _ANSWER_PROP_NAMES:
                        arguments[key] = value
            for prop in spec.properties:
                if _normalize(prop) in _ANSWER_PROP_NAMES:
                    arguments[prop] = answer
            observation = await self.call_tool(name, arguments)
            if observation.ok:
                self._think(f"Submitted the answer through {name}")
                return observation
        return None

    async def _plan_arguments(self, tools: list[str]) -> dict[str, dict[str, Any]]:
        """Ask the model to fill required arguments from the evidence."""
        model = self._model("solve")
        if not model:
            return {}
        schema_block = []
        for name in tools:
            spec = self.catalog.get(name)
            if spec is None:
                continue
            schema_block.append(
                json.dumps(
                    {
                        "tool": name,
                        "description": spec.description,
                        "input_schema": spec.input_schema,
                    },
                    ensure_ascii=False,
                )
            )
        prompt = (
            "You must call the MCP tools listed below. For each one, write the arguments "
            "object that the tool's JSON schema requires, using concrete values from the "
            "evidence. Do not invent identifiers that no evidence produced.\n\n"
            f"Tools:\n" + "\n".join(schema_block) + "\n\n"
            f"Evidence so far:\n{self._evidence(max_chars=4000)}\n\n"
            'Reply with a JSON array only: [{"tool": "<name>", "arguments": {...}}, ...]'
        )
        reply = await self._chat(
            model=model,
            messages=[
                {"role": "system", "content": "You plan tool calls. Reply with JSON only."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=900,
            timeout=min(45.0, max(12.0, self.clock.remaining() - self.strategy.submit_reserve_s)),
        )
        return _parse_plan(reply.content)

    def _minimal_arguments(self, name: str) -> dict[str, Any]:
        spec = self.catalog.get(name)
        if spec is None:
            return {}
        minimal: dict[str, Any] = {}
        for prop, details in spec.required_props():
            details = details if isinstance(details, dict) else {}
            if _normalize(prop) in {"agent_id", "agentid", "session_id"}:
                minimal[prop] = self.agent_id
            else:
                minimal[prop] = _default_for_schema(details)
        return minimal

    # ---- stage 3: LLM exploration loop ----------------------------------
    async def explore(self, *, rounds: int) -> None:
        """Let the model pick the next tool each round until it is ready."""
        model = self._model("explore")
        if not model:
            return
        for round_index in range(1, max(0, rounds) + 1):
            remaining = self.clock.remaining()
            if remaining < self.strategy.min_useful_step_s:
                self._log(f"   Exploration stopped: {remaining:.0f}s left")
                break
            self.rounds = round_index
            reply = await self._decision_round(model, round_index, remaining)
            if reply is None:
                break
            if reply.error:
                self._log(f"   Model error on round {round_index}: {reply.error[:200]}")
                if reply.fatal:
                    self._log("   Model budget is exhausted; stopping exploration")
                    break
                continue
            nudged = False
            if not reply.tool_calls and not reply.error and self.json_protocol:
                reply.tool_calls = _parse_action_json(reply.content)
            while not reply.tool_calls and not reply.error:
                value = answers.strict_final_value(
                    reply.content, self.rules, tuple(self.catalog.names)
                )
                if value:
                    self.candidate = value
                    self._log(f"   Explorer reported an answer: {value[:120]}")
                    return
                if nudged or answers.looks_like_tool_markup(reply.content):
                    self._log("   Explorer produced no actionable output this round")
                    break
                # One corrective turn: a model that described an action instead
                # of taking one gets told exactly what the reply must look like.
                nudged = True
                reply = await self._decision_round(
                    model, round_index, self.clock.remaining(), nudge=reply.content[:600]
                )
                if reply is None:
                    break
            if not reply or not reply.tool_calls:
                continue
            executed = 0
            for call in reply.tool_calls[:2]:
                if self.clock.remaining() < self.strategy.min_useful_step_s and executed:
                    break
                if call.parse_error:
                    self._log(f"   Unparseable arguments for {call.name}: {call.parse_error[:120]}")
                    continue
                name, arguments, allow_unlisted = self._resolve_requested_call(call)
                if not name:
                    continue
                if not self.candidate and self._is_submit_like(name):
                    # A submission tool ends the challenge at the server. The
                    # model may hold a real value but must finalize first, so
                    # the answer stage can normalize and complete the arguments.
                    held = Observation(
                        index=self._next_index,
                        tool=name,
                        arguments=dict(arguments),
                        error=(
                            "held: an answer-submission tool is not called during "
                            "exploration. Reply 'FINAL_ANSWER: <value>' when ready, then it "
                            "is submitted with its required companions."
                        ),
                        held=True,
                    )
                    self._next_index += 1
                    self._remember_observation(held)
                    self._log(f"   Held submission tool {name} until the answer is final")
                    executed += 1
                    continue
                observation = await self.call_tool(
                    name,
                    arguments,
                    allow_unlisted=allow_unlisted,
                    timeout=min(40.0, max(6.0, self.clock.remaining() - self.strategy.submit_reserve_s)),
                )
                executed += 1
                if observation.ok and observation.result:
                    self._maybe_think_observation(observation)
            if executed == 0:
                continue
            if not self.has_challenge_payload and not self._swept:
                # Still lost after a real round: stop guessing and vary the
                # schema's own value space. A capability hidden behind an enum
                # value is invisible to name-based reasoning.
                self._swept = True
                await self.sweep_enums(limit=4)
            if self._catalog_dirty:
                await self.refresh_catalog()
        self.timed_out = self.clock.remaining() <= self.strategy.min_useful_step_s
        missing = self.missing_required()
        if missing:
            self._log(f"   Still uncovered after exploration: {', '.join(missing)}")

    def _resolve_requested_call(
        self, call: ToolCall
    ) -> tuple[str, dict[str, Any], bool]:
        """Map a model request to a real tool call.

        Returns ``(tool, arguments, allow_unlisted)``. The escape-hatch tool is
        unwrapped here, which is how a hidden capability revealed by evidence
        gets exercised even though the server never advertised it.
        """
        if call.name == _ESCAPE_TOOL:
            target = str(call.arguments.get("tool_name") or "").strip()
            arguments = call.arguments.get("arguments")
            if isinstance(arguments, str):
                arguments, _error = _parse_arguments(arguments)
            if not isinstance(arguments, dict):
                arguments = {}
            if not target:
                self._log("   Escape-hatch call had no tool_name")
                return "", {}, False
            real = self._real_name(target) or target
            self._log(f"   Probing unlisted tool {real!r} from evidence")
            return real, dict(arguments), True
        real = self._real_name(call.name)
        if real is None:
            # An unknown name is not a mistake to discard: on a black-box
            # server it may be a hidden tool the evidence named.
            if re.fullmatch(r"[A-Za-z0-9_.:-]{2,120}", call.name or ""):
                self._log(f"   Explorer requested unlisted tool {call.name!r}; probing it")
                self._catalog_dirty = True
                return call.name, dict(call.arguments), True
            return "", {}, False
        return real, dict(call.arguments), True

    async def _decision_round(
        self,
        model: str,
        round_index: int,
        remaining: float,
        *,
        nudge: str = "",
    ) -> Reply | None:
        """One stateless decision: catalog + evidence + clock in, action out."""
        timeout = min(
            90.0,
            max(15.0, remaining - self.strategy.submit_reserve_s),
        )
        # With native tool calling the function definitions already carry every
        # name, description, and schema. Repeating them as text is pure prompt
        # overhead; keep the text only for the JSON protocol or aliased names.
        catalog_section = ""
        if self.json_protocol or self.aliased_tools:
            catalog_section = (
                f"Discovered catalog ({len(self.catalog)} tools):\n"
                f"{self._catalog_block()}\n\n"
            )
        messages = [
            {"role": "system", "content": self._explorer_system_prompt()},
            {
                "role": "user",
                "content": (
                    f"{catalog_section}"
                    f"Task payload:\n{render_value(self.challenge, max_chars=1400)}\n\n"
                    f"Observations so far:\n{self._evidence(max_chars=4200)}\n\n"
                    f"{self._signals()}"
                    f"Clock: {remaining:.0f}s left. Exploration round {round_index} of "
                    f"{self.strategy.tool_rounds}.\n"
                    "Choose the single most useful next action. Either call a tool, or finalize "
                    "with FINAL_ANSWER if the evidence is sufficient."
                ),
            },
        ]
        if nudge:
            messages.append({"role": "assistant", "content": nudge})
            messages.append(
                {
                    "role": "user",
                    "content": (
                        "That reply did not contain a tool call and did not finalize. Do one of "
                        "these exactly: emit a tool call now, or reply 'FINAL_ANSWER: <value>'."
                    ),
                }
            )
        reply = await self._chat(
            model=model,
            messages=messages,
            tools=None if self.json_protocol else self._model_tools(),
            max_tokens=self.strategy.explore_max_tokens,
            timeout=timeout,
        )
        # Self-heal the tool protocol. First rename MCP identifiers that a
        # provider refuses (dots are common), then, if the provider rejects
        # tools entirely, fall back to a JSON action reply.
        for _attempt in range(2):
            if not reply.error or self.json_protocol:
                break
            if not self._is_tool_schema_error(reply.error):
                break
            if not self.aliased_tools:
                self.aliased_tools = True
                self._build_alias_map()
                self._log("   Provider rejected MCP function names; switching to aliases")
            else:
                self.json_protocol = True
                self._log("   Provider rejected tool calling; switching to a JSON action protocol")
                messages = [
                    {"role": "system", "content": self._explorer_system_prompt()},
                    *messages[1:],
                ]
            reply = await self._chat(
                model=model,
                messages=messages,
                tools=None if self.json_protocol else self._model_tools(),
                max_tokens=self.strategy.explore_max_tokens,
                timeout=timeout,
            )
        return reply

    async def _chat(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        timeout: float,
        tools: list[dict[str, Any]] | None = None,
    ) -> Reply:
        """Run a blocking proxy call off the event loop with a hard timeout."""
        if not model:
            return Reply(error="no model available")
        remaining = self.clock.remaining()
        if remaining <= self.strategy.submit_reserve_s:
            return Reply(error="time budget exhausted")
        budget = max(4.0, min(float(timeout), remaining - self.strategy.submit_reserve_s))
        try:
            return await asyncio.wait_for(
                asyncio.to_thread(self.llm.chat, model=model, messages=messages,
                                  max_tokens=max_tokens, timeout=budget, tools=tools),
                timeout=budget + 3.0,
            )
        except asyncio.TimeoutError:
            return Reply(error=f"model call exceeded {budget:.0f}s")
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            return Reply(error=message, fatal=_is_fatal_model_error(message))

    # ---- stage 4: answer ------------------------------------------------
    async def answer(self) -> str:
        """Produce, normalize, and cross-check the final value."""
        if not self.has_challenge_payload:
            # No task was recovered, so an answer model can only hallucinate.
            self._log("   No task payload was recovered; skipping the answer model")
            return self._fallback()
        first = self.candidate
        if not first:
            first = await self._answer_call(self._model("answer"), self.strategy.answer_prompt)
        if not first:
            return self._fallback()

        if self._should_verify():
            # One attempt only: a verifier that stalls or returns nothing must
            # not consume the budget a submission needs.
            second = await self._answer_call(
                self._model("verify"), self.strategy.verifier_prompt, attempts=1
            )
            if second and not answers.answers_agree(first, second):
                self._log(f"   Verifier disagreed: {second[:120]}")
                resolved = await self._resolve(first, second)
                if resolved:
                    first = resolved
            elif second:
                self._log("   Verifier agreed")
        return first or self._fallback()

    def _should_verify(self) -> bool:
        ctx = self.context()
        remaining = self.clock.remaining()
        if not self.strategy.should_verify(ctx, remaining):
            return False
        return len(self.ranked_models) > 1 or bool(self.candidate)

    async def _answer_call(self, model: str, template: str, *, attempts: int = 2) -> str:
        if not model:
            return ""
        prompt = template.format(
            description=self.description or "(no challenge statement was recovered)",
            rules=self.rules or "(no explicit format rules were provided)",
            evidence=self._evidence(max_chars=self.strategy.transcript_char_budget),
            first=self.candidate or "",
            second="",
        )
        timeout = min(self.strategy.answer_timeout_s, max(8.0, self.clock.remaining() - self.strategy.submit_reserve_s))
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": self.strategy.build_system_prompt(self.context())},
            {"role": "user", "content": prompt},
        ]
        known_tools = tuple(self.catalog.names)
        for attempt in range(max(1, attempts)):
            reply = await self._chat(
                model=model,
                messages=messages,
                max_tokens=self.strategy.answer_max_tokens,
                timeout=timeout,
            )
            if reply.error:
                self._log(f"   Answer model {model} failed: {reply.error[:160]}")
                return ""
            value = answers.answer_value_from_reply(
                reply.content, self.rules, known_tools=known_tools
            )
            if value:
                self._log(f"   Answer candidate from {model}: {value[:140]}")
                return value
            reason = answers.rejection_reason(reply.content, known_tools)
            self._log(f"   Rejected {model} reply ({reason[:120]})")
            if attempt + 1 >= max(1, attempts) or self.clock.remaining() < self.strategy.submit_reserve_s + 12:
                return ""
            messages = [
                *messages,
                {"role": "assistant", "content": (reply.content or "")[:800]},
                {
                    "role": "user",
                    "content": (
                        f"That reply was rejected: {reason}. Return only the answer value in "
                        "the required format now. No label, no quotes, no explanation."
                    ),
                },
            ]
        return ""

    async def _resolve(self, first: str, second: str) -> str:
        """Adjudicate two disagreeing answers with a third, independent solve."""
        model = self._model("answer")
        if not model or self.clock.remaining() < self.strategy.submit_reserve_s + 10:
            return first
        prompt = self.strategy.resolve_disagreement_prompt.format(
            description=self.description,
            rules=self.rules or "(no explicit format rules were provided)",
            evidence=self._evidence(max_chars=5000),
            first=first,
            second=second,
        )
        reply = await self._chat(
            model=model,
            messages=[
                {"role": "system", "content": "You adjudicate between candidate answers. Reply with the value only."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=self.strategy.answer_max_tokens,
            timeout=self.strategy.verify_timeout_s,
        )
        if reply.error:
            return first
        resolved = answers.answer_value_from_reply(
            reply.content, self.rules, known_tools=tuple(self.catalog.names)
        )
        return resolved or first

    def _fallback(self) -> str:
        evidence = self._evidence(max_chars=2000)
        guess = answers.plausible_fallback(
            self.clues, self.description or self.rules, self.rules, evidence
        )
        if guess:
            self._log(f"   Deterministic fallback answer: {guess[:140]}")
        return guess

    def answer_sync_fallback(self) -> str:
        """A value that can be submitted without another model round trip.

        Called when the deadline guard cancelled the solve, so it must be pure
        local work. ``unknown`` is the documented last resort: a submitted
        answer that may be wrong always beats a missing submission.
        """
        return self._fallback() or "unknown"

    # ---- prompt material -------------------------------------------------
    def _catalog_block(self) -> str:
        lines = []
        for name in self.catalog.names:
            display = self._real_to_alias.get(name) if self.aliased_tools else name
            spec = self.catalog.require(name)
            if self.aliased_tools and display != name:
                lines.append(f"- {display} (server tool {name}): {spec.summary_line(description_chars=200)}")
            else:
                lines.append(f"- {spec.summary_line(description_chars=200)}")
        if self.strategy.discovered_tool_escape_hatch:
            lines.append(
                f"- {_ESCAPE_TOOL}(tool_name: string, arguments?: object): call a tool name that "
                "evidence revealed but the catalog does not list. Use it for hidden capabilities."
            )
        return "\n".join(lines)

    def _explorer_system_prompt(self) -> str:
        prompt = str(self.strategy.explorer_system_prompt).strip()
        if self.json_protocol:
            return f"{prompt}\n\n{self.strategy.explorer_protocol_note}"
        return prompt

    def _model_tools(self) -> list[dict[str, Any]]:
        """Function definitions for the discovered catalog plus the escape hatch."""
        tools: list[dict[str, Any]] = []
        for name in self.catalog.names:
            spec = self.catalog.require(name)
            parameters = spec.input_schema or {"type": "object", "properties": {}}
            if not isinstance(parameters, dict) or parameters.get("type") != "object":
                parameters = {"type": "object", "properties": {}}
            if "properties" not in parameters:
                parameters = {**parameters, "properties": {}}
            exposed = self._real_to_alias.get(name, name) if self.aliased_tools else name
            description = spec.description or (
                f"Server tool {name}. No description was provided; infer its role from the "
                "name and its input schema, and call it when the task fits."
            )
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": exposed,
                        "description": description[:1000],
                        "parameters": parameters,
                    },
                }
            )
        if self.strategy.discovered_tool_escape_hatch:
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": _ESCAPE_TOOL,
                        "description": (
                            "Call a tool by name that the catalog does not list, typically one "
                            "revealed by a tool result. Arguments are passed through as given. "
                            "Use only when evidence names the tool."
                        ),
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "tool_name": {"type": "string", "description": "Exact server tool name."},
                                "arguments": {
                                    "type": "object",
                                    "description": "Arguments object for that tool.",
                                    "additionalProperties": True,
                                },
                            },
                            "required": ["tool_name"],
                        },
                    },
                }
            )
        return tools

    def _build_alias_map(self) -> None:
        for name in self.catalog.names:
            alias = re.sub(r"[^A-Za-z0-9_-]", "_", name)[:64] or "tool"
            if alias in self._alias_to_real and self._alias_to_real[alias] != name:
                alias = f"tool_{len(self._alias_to_real) + 1}"
            self._alias_to_real[alias] = name
            self._real_to_alias[name] = alias

    def _real_name(self, requested: str) -> str | None:
        """Map a model-facing name to the real server tool, or None if unlisted."""
        name = str(requested or "").strip()
        if not name:
            return None
        if name == _ESCAPE_TOOL:
            return name
        if name in self.catalog:
            return name
        mapped = self._alias_to_real.get(name)
        if mapped:
            return mapped
        return None

    def _evidence(self, *, max_chars: int) -> str:
        lines: list[str] = []
        total = 0
        for observation in self.observations:
            if observation.cached:
                # A replayed call carries exactly the earlier result; feeding
                # it back again only grows the prompt.
                continue
            rendered = observation.as_evidence()
            if not rendered.strip():
                continue
            if total + len(rendered) > max_chars:
                remaining = max_chars - total
                if remaining > 200:
                    lines.append(rendered[:remaining].rstrip() + " ...")
                break
            lines.append(rendered)
            total += len(rendered)
        return "\n".join(lines) or "(no evidence yet)"

    def _signals(self) -> str:
        """Point the model at likely next hops in the evidence."""
        hints: list[str] = []
        blob = "\n".join(observation.as_evidence() for observation in self.observations)
        if re.search(r"\b[A-Za-z0-9+/]{40,}={0,2}\b", blob):
            hints.append(
                "evidence contains a long encoded-looking blob; look for a decode/decrypt tool "
                "and feed it that exact value"
            )
        if re.search(r"\b[0-9a-f]{32,}\b", blob, flags=re.IGNORECASE):
            hints.append("evidence contains a hex string; a cipher/hex tool is a likely next hop")
        if re.search(r"https?://", blob):
            hints.append("evidence contains a URL; a fetch/read tool is a likely next hop")
        uncovered = self.missing_required()
        if uncovered:
            hints.append("still uncovered required tools: " + ", ".join(uncovered))
        if self.id_pool and not self.clues:
            hints.append("identifiers discovered: " + ", ".join(self.id_pool[:8]))
        if not hints:
            return ""
        return "Signals:\n- " + "\n- ".join(hints) + "\n\n"

    def _maybe_think_observation(self, observation: Observation) -> None:
        """Broadcast a short, meaningful note as the chain progresses."""
        if not observation.ok:
            return
        if observation.tool in {"image_generate", "image_edit"}:
            self._think(f"Produced image output via {observation.tool}")
            return
        if observation.tool in self._called and len(self.observations) % 4 == 0:
            self._think(f"Explored {len(self._called)} tools; {self.clock.remaining():.0f}s left")

    def _is_tool_schema_error(self, error: str) -> bool:
        text = str(error or "").casefold()
        return any(token in text for token in ("tool", "function name", "functions", "schema"))

    # ---- image helpers used by imagery.py -------------------------------
    def harvest_from(self, result: Any) -> None:
        self._harvest(result)

    def note_required(self, names: list[str]) -> None:
        for name in names:
            if name and name not in self.required_tools:
                self.required_tools.append(name)


def _normalize(prop: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(prop).casefold()).strip("_")


def _tool_tokens(tool: str) -> list[str]:
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(tool or ""))
    return [part for part in re.split(r"[^a-z0-9]+", spaced.casefold()) if part]


def _is_id_prop(prop: str) -> bool:
    normalized = _normalize(prop)
    return normalized.endswith(_ID_PROP_SUFFIXES) or normalized in {"id", "ids", "uuid"}


def _default_for_schema(schema: dict[str, Any]) -> Any:
    label = str(schema.get("type") or "")
    if label in {"string", "str"}:
        return ""
    if label in {"integer", "int"}:
        return 0
    if label in {"number", "float"}:
        return 0.0
    if label in {"boolean", "bool"}:
        return False
    if label == "array":
        return []
    if label == "object":
        return {}
    return ""


def _enumerable_props(spec: Any) -> list[tuple[str, list[Any]]]:
    """Schema properties with a small declared value space, for pair sweeps."""
    enumerable: list[tuple[str, list[Any]]] = []
    for prop, details in spec.properties.items():
        if not isinstance(details, dict):
            continue
        values: list[Any] = []
        enum = details.get("enum")
        if isinstance(enum, list):
            default = details.get("default", _MISSING)
            values = [
                value
                for value in enum
                if value != default and isinstance(value, (str, int, bool))
            ][:3]
        elif str(details.get("type")) == "boolean":
            if details.get("default") is not True:
                values = [True]
        elif str(details.get("type")) in {"integer", "number"}:
            default = details.get("default")
            values = [value for value in (0, 1, 2, 3) if value != default]
            if isinstance(default, int) and default + 1 not in values:
                values.append(default + 1)
            values = values[:4]
        if values:
            enumerable.append((prop, values))
    return enumerable


def _looks_like_challenge(node: Any) -> bool:
    if not isinstance(node, dict):
        return False
    keys = {str(key).casefold() for key in node}
    has_question = bool(
        keys & {"description", "question", "statement", "prompt", "challenge_text"}
    )
    has_format = bool(
        keys & {"rules", "output_format", "answer_format", "required_tools", "clues"}
    )
    return has_question and has_format


def _walk_dicts(node: Any, depth: int = 0):
    if depth > 6:
        return
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk_dicts(value, depth + 1)
    elif isinstance(node, list):
        for item in node[:50]:
            yield from _walk_dicts(item, depth + 1)


def _select_task_record(payload: Any) -> dict[str, Any] | None:
    """Pick the live task out of a payload that holds several task records.

    Returns ``None`` when there is one clear task or no clear winner, so an
    ordinary single-task payload is untouched.
    """
    candidates: list[tuple[dict[str, Any], dict[str, Any]]] = []
    seen: set[int] = set()
    for node in _walk_dicts(payload):
        for value in node.values():
            if isinstance(value, dict) and _looks_like_challenge(value) and id(value) not in seen:
                seen.add(id(value))
                candidates.append((node, value))
        if _looks_like_challenge(node) and id(node) not in seen:
            seen.add(id(node))
            candidates.append((node, node))
    if len(candidates) < 2:
        return None

    def score(pair: tuple[dict[str, Any], dict[str, Any]]) -> int:
        container, challenge = pair
        text = json.dumps(container, default=str).casefold()
        value = 0
        if any(token in text for token in ('"active"', '"live"', '"current"', '"open"', '"running"')):
            value += 3
        if any(token in text for token in ("archived", "stale", "closed", "inactive", "draft", "deprecated")):
            value -= 5
        if challenge.get("required_tools"):
            value += 2
        if challenge.get("rules") or challenge.get("output_format"):
            value += 1
        if challenge.get("max_time_s"):
            value += 1
        return value

    best = max(candidates, key=score)
    others = [score(pair) for pair in candidates if pair is not best]
    if not others or score(best) <= max(others):
        return None
    return best[1]


def _enum_probes(
    schema: dict[str, Any],
    prefix: tuple[str, ...] = (),
    depth: int = 0,
) -> list[tuple[tuple[str, ...], Any]]:
    """Non-default enum values declared anywhere in a tool schema.

    Nested enums matter: a filter object whose ``kind`` selects text or image
    is exactly how a server can hide one challenge behind another.
    """
    probes: list[tuple[tuple[str, ...], Any]] = []
    if depth > 2 or not isinstance(schema, dict):
        return probes
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return probes
    for prop, details in properties.items():
        if not isinstance(details, dict):
            continue
        values = details.get("enum")
        if isinstance(values, list):
            default = details.get("default", _MISSING)
            for value in values:
                if value == default or not isinstance(value, (str, int, bool)):
                    continue
                probes.append((prefix + (prop,), value))
        if isinstance(details.get("properties"), dict):
            probes.extend(_enum_probes(details, prefix + (prop,), depth + 1))
    return probes


def _nest(path: tuple[str, ...], value: Any) -> dict[str, Any]:
    """Build ``{a: {b: value}}`` from ``(("a", "b"), value)``."""
    node: Any = value
    for key in reversed(path):
        node = {key: node}
    return node if isinstance(node, dict) else {}


def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in overlay.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _named_scalars(result: Any, *, limit: int = 32) -> list[tuple[str, str]]:
    """Short ``key -> value`` strings a tool revealed (nonce, token, key...).

    These are the values a later tool may require, so they are kept by name and
    fed back through schema-driven argument synthesis. Descriptive keys are
    skipped: they are prose, not handles.
    """
    noise = {
        "status", "note", "notes", "error", "hint", "description", "rules",
        "prompt", "message", "kind", "type", "encoding", "label", "title",
        "summary", "text", "content", "answer", "reason", "rationale",
    }
    found: list[tuple[str, str]] = []
    for key, value in _walk(result):
        normalized = _normalize(key)
        if len(found) >= limit:
            break
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,30}", normalized):
            continue
        if normalized in noise or normalized.startswith("required"):
            continue
        if isinstance(value, str):
            text = value.strip()
            if 0 < len(text) <= 200 and "\n" not in text:
                found.append((normalized, text))
        elif isinstance(value, int) and not isinstance(value, bool):
            found.append((normalized, str(value)))
    return found


def _identifier_values(result: Any, *, limit: int = 24) -> list[str]:
    """Identifiers revealed by a result: list entries and id-ish keys."""
    found: list[str] = []

    def accept(value: Any) -> None:
        if not isinstance(value, str):
            return
        text = value.strip()
        if not text or len(text) > 80 or " " in text or "\n" in text:
            return
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}", text):
            return
        if text in found:
            return
        if len(found) < limit:
            found.append(text)

    for key, value in _walk(result):
        lowered = key.casefold()
        if isinstance(value, (list, tuple)):
            if any(token in lowered for token in ("id", "clue", "item", "key", "token")):
                for item in value:
                    if isinstance(item, str):
                        accept(item)
                    elif isinstance(item, dict):
                        for candidate in ("id", "clue_id", "key", "name"):
                            accept(item.get(candidate))
            # A list of records can carry handles under an id field even when
            # the list itself is named "documents" or "tasks"; that is how a
            # renamed server still yields the id the next tool needs.
            for item in value:
                if isinstance(item, dict):
                    for item_key, item_value in item.items():
                        if _is_id_prop(str(item_key)):
                            accept(item_value)
        elif _is_id_prop(key):
            accept(value)
    return found


def _tool_error(result: Any) -> str:
    """Recognize error payloads the MCP layer returns instead of raising."""
    if not isinstance(result, dict):
        return ""
    error = result.get("error")
    if isinstance(error, str) and error.strip():
        return error.strip()
    if isinstance(error, dict) and error:
        return json.dumps(error, ensure_ascii=False)[:400]
    raw = result.get("raw")
    if isinstance(raw, str):
        # A server that answers an unknown tool with a text payload instead of
        # a protocol error must still be read as a failure.
        if raw.strip().casefold().startswith("error executing tool"):
            return raw.strip()[:400]
        if _looks_like_unknown_tool(raw):
            return raw.strip()[:400]
    for key in ("message", "detail", "reason"):
        value = result.get(key)
        if isinstance(value, str) and _looks_like_unknown_tool(value):
            return value.strip()[:400]
    return ""


def _looks_like_unknown_tool(text: str) -> bool:
    lowered = str(text or "").casefold()
    return any(
        marker in lowered
        for marker in (
            "unknown tool",
            "tool not found",
            "no such tool",
            "unrecognized tool",
            "not a valid tool",
            "no tool named",
        )
    )


def _is_schema_error(error: str) -> bool:
    """True when the server rejected the argument names or shape itself."""
    text = str(error or "").casefold()
    return any(
        marker in text
        for marker in (
            "validation error",
            "field required",
            "unexpected keyword",
            "invalid arguments",
            "input should be",
        )
    )


def _missing_fields(error: str) -> list[str]:
    """Field names a pydantic-style validation error says are required."""
    return re.findall(
        r"(?m)^\s{0,4}([A-Za-z_][A-Za-z0-9_]*)\s*$\s*\n\s*Field required",
        str(error or ""),
    )


def _is_fatal_model_error(error: str) -> bool:
    """True when retrying cannot help: a quota or billing stop, not a blip."""
    text = str(error or "").casefold()
    return any(
        marker in text
        for marker in (
            "daily_limit",
            "daily limit",
            "insufficient_quota",
            "quota exceeded",
            "billing",
            "credit balance",
        )
    )


def _parse_action_json(content: str) -> list[ToolCall]:
    """Parse a JSON-protocol action reply into a tool call.

    Used only when the provider refuses native tool calling, so the same
    exploration loop still runs over a pure chat interface.
    """
    text = str(content or "").strip()
    if not text:
        return []
    candidates = [text, *_fenced_blocks(text)]
    object_start = text.find("{")
    if object_start >= 0:
        candidates.append(_first_json_object(text))
    for candidate in candidates:
        if not candidate:
            continue
        try:
            payload = json.loads(candidate)
        except (TypeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        name = str(payload.get("tool") or payload.get("name") or payload.get("tool_name") or "").strip()
        if not name:
            continue
        arguments = payload.get("arguments")
        if isinstance(arguments, str):
            arguments, _error = _parse_arguments(arguments)
        if not isinstance(arguments, dict):
            arguments = {}
        return [ToolCall(name=name, arguments=arguments)]
    return []


def _fenced_blocks(text: str) -> list[str]:
    return [block.strip() for block in re.findall(r"```[a-zA-Z0-9_+-]*\s*(.*?)```", text, flags=re.DOTALL)]


def _parse_plan(content: str) -> dict[str, dict[str, Any]]:
    """Parse the argument-planner reply into ``{tool: arguments}``."""
    text = str(content or "").strip()
    if not text:
        return {}
    candidates = [text]
    fenced = re.findall(r"```[a-zA-Z0-9_+-]*\s*(.*?)```", text, flags=re.DOTALL)
    candidates.extend(fenced)
    array_start = text.find("[")
    array_end = text.rfind("]")
    if 0 <= array_start < array_end:
        candidates.append(text[array_start : array_end + 1])
    object_start = text.find("{")
    if object_start >= 0:
        candidates.append(_first_json_object(text))
    for candidate in candidates:
        if not candidate:
            continue
        try:
            payload = json.loads(candidate)
        except (TypeError, json.JSONDecodeError):
            continue
        entries = payload if isinstance(payload, list) else [payload]
        plan: dict[str, dict[str, Any]] = {}
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("tool") or entry.get("name") or "").strip()
            arguments = entry.get("arguments")
            if isinstance(arguments, str):
                arguments, _error = _parse_arguments(arguments)
            if name and isinstance(arguments, dict):
                plan[name] = arguments
        if plan:
            return plan
    return {}
