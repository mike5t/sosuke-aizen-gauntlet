"""Image challenge branch: analyze, refine, render, submit.

Image challenges are not a different philosophy, only a different payoff: the
tool chain ends in an image URI instead of a text value. The chain here is the
one an image challenge actually implies:

1. read the challenge (prompt, reference notes, optional source image),
2. describe the source image with an analyze tool when one exists, so an edit
   preserves what the judge checks for,
3. refine the challenge's own instruction into one production prompt,
4. render with the best advertised image model, retrying on model failure,
5. submit through the discovered submit tool, with a REST fallback.

Nothing hardcodes a tool name: roles come from names and JSON schemas.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Callable

import answers
from catalog import ToolCatalog

from my_strategy import MyStrategy


_PAYLOAD_PROPS = ("edited_image", "image_uri", "image_url", "image", "output_image", "output")


@dataclass
class ImageOutcome:
    """What the image branch produced, for submission and for the run record."""

    image_uri: str = ""
    prompt: str = ""
    tool: str = ""
    model: str = ""
    attempts: int = 0
    analysis: str = ""
    required_calls: list[str] = field(default_factory=list)
    error: str = ""


def _nested_text(payload: Any, keys: set[str], *, max_depth: int = 5) -> str:
    """Longest string under a matching key anywhere in a nested payload."""
    best = ""

    def walk(node: Any, depth: int) -> None:
        nonlocal best
        if depth > max_depth:
            return
        if isinstance(node, dict):
            for key, value in node.items():
                if str(key).casefold() in keys and isinstance(value, str) and value.strip():
                    if len(value.strip()) > len(best):
                        best = value.strip()
                walk(value, depth + 1)
        elif isinstance(node, list):
            for item in node[:20]:
                walk(item, depth + 1)

    walk(payload, 0)
    return best


def image_instruction(payload: dict[str, Any], explorer_description: str) -> tuple[str, str]:
    """Recover ``(instruction, notes)`` from an image challenge payload.

    The payload may be flat or nested under a wrapper key, so both are read.
    """
    instruction = _nested_text(
        payload, {"prompt", "edit_prompt", "image_prompt", "instruction"}
    )
    notes = _nested_text(
        payload, {"reference_notes", "notes", "guidance", "constraints"}
    )
    if not instruction:
        instruction = explorer_description or ""
    return instruction, notes


def _find_image_uri(result: Any, *, depth: int = 0) -> str:
    """Pull an image URI out of a tool result, wherever the server put it."""
    if depth > 5:
        return ""
    if isinstance(result, str):
        text = result.strip()
        if text.startswith("data:image/"):
            return text
        if re.match(r"https?://", text) and re.search(r"\.(png|jpe?g|webp|gif)(\?|$)", text, re.I):
            return text
        return ""
    if isinstance(result, dict):
        # Prefer keys that say "image" over generic url keys.
        for key, value in result.items():
            if "image" in str(key).casefold():
                found = _find_image_uri(value, depth=depth + 1)
                if found:
                    return found
        for key, value in result.items():
            if str(key).casefold() in {"uri", "url", "output", "result", "data"}:
                found = _find_image_uri(value, depth=depth + 1)
                if found:
                    return found
    if isinstance(result, (list, tuple)):
        for item in result:
            found = _find_image_uri(item, depth=depth + 1)
            if found:
                return found
    return ""


def _result_text(result: Any) -> str:
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        for key in ("text", "analysis", "description", "answer", "result"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return json.dumps(result, ensure_ascii=False, default=str)[:4000]
    return ""


class ImageRunner:
    """Run the image chain for one image challenge."""

    def __init__(
        self,
        *,
        explorer: Any,
        catalog: ToolCatalog,
        strategy: MyStrategy,
        ranked_models: list[str],
        think: Callable[[str], Any] | None = None,
        log: Callable[[str], None] | None = None,
    ) -> None:
        self.explorer = explorer
        self.catalog = catalog
        self.strategy = strategy
        self.ranked_models = [model for model in ranked_models if model]
        self._think = think or (lambda _text: None)
        self._log = log or (lambda _text: print(_text, flush=True))
        self.outcome = ImageOutcome()

    def image_models(self) -> list[str]:
        """Image-capable aliases in ranked order."""
        preferred = self.strategy.prefer_image_models(self.ranked_models)
        return preferred or self.ranked_models

    def text_model(self) -> str:
        """The best non-image alias, used for planning and prompt writing.

        Image aliases are ranked first for image challenges, so they must be
        filtered out here: a rendered-image model makes a poor prompt planner
        and spends image-model budget on text.
        """
        image_set = set(self.image_models())
        text_models = [model for model in self.ranked_models if model not in image_set]
        if text_models:
            return text_models[0]
        return self.ranked_models[0] if self.ranked_models else ""

    async def run(self) -> ImageOutcome:
        outcome = self.outcome
        payload = self.explorer.challenge or {}
        instruction, notes = image_instruction(payload, self.explorer.description)
        outcome.prompt = instruction
        if not instruction:
            outcome.error = "no image instruction recovered from the challenge payload"
            self._log(f"   Image branch: {outcome.error}")
            return outcome

        analysis = await self._analyze_source(instruction)
        outcome.analysis = analysis
        refined = await self._refine_prompt(instruction, notes, analysis)
        base_prompt = refined or instruction
        if analysis and analysis[:120].casefold() not in base_prompt.casefold():
            # The analyze hop must feed the render even when the instruction
            # needed no rewrite; otherwise the source description is wasted.
            base_prompt = (
                f"{base_prompt}\n\nSource image details to preserve: {analysis[:1200]}"
            )
        if _env_mode("EXPLORER_IMAGE_CLAUSE", "auto") == "off":
            # Dev knob for the measured no-text experiment.
            outcome.prompt = base_prompt.strip()
        else:
            outcome.prompt = _with_constraints(base_prompt, instruction, notes)
        if self.explorer.image_uri:
            # Preservation wording for edits. "change_only" is the measured
            # winner (round 5: preservation 74.0 vs 66.6 without it, accuracy up
            # to 93.4); the knob stays for future A/B runs.
            outcome.prompt = _with_preservation(
                outcome.prompt, mode=_env_mode("EXPLORER_IMAGE_PRESERVE", "change_only")
            )
        self._log(f"   Image prompt: {outcome.prompt[:200]}")

        roles = self.catalog.image_tool_roles()
        wants_edit = bool(self.explorer.image_uri)
        ordered_roles = self._ranked_roles(roles, wants_edit=wants_edit)
        if not ordered_roles:
            outcome.error = "no image output tool discovered"
            self._log(f"   Image branch: {outcome.error}")
            return outcome

        rate_limited = False
        for role, tool_name in ordered_roles:
            if rate_limited:
                break
            if self.explorer.clock.remaining() < self.strategy.submit_reserve_s:
                outcome.error = "time budget exhausted before rendering"
                break
            models = self.image_models()[:2]
            for model in models:
                outcome.attempts += 1
                result = await self._render(tool_name, role, outcome.prompt, model)
                uri = _find_image_uri(result) if result is not None else ""
                if uri:
                    outcome.image_uri = uri
                    outcome.tool = tool_name
                    outcome.model = model
                    self.explorer.harvest_from(result)
                    self._log(f"   Image rendered by {tool_name} with {model}")
                    return outcome
                error = _tool_error(result)
                self._log(
                    f"   Image tool {tool_name} with {model} produced no image"
                    + (f": {error[:160]}" if error else "")
                )
                if _is_rate_limit(error):
                    # The proxy rate-limits image models per agent id, so a
                    # retry on the same id in the same run rarely clears it and
                    # trying the other aliases and roles only burns the clock.
                    # A generation has no fallback image, so it gets one paused
                    # retry; an edit can fall back to its source image instead.
                    retry_worthwhile = not self.explorer.image_uri
                    if retry_worthwhile and not rate_limited and (
                        self.explorer.clock.remaining() > self.strategy.submit_reserve_s + 12
                    ):
                        rate_limited = True
                        self._log(
                            "   Image proxy rate limit; pausing before one retry "
                            "(no source image to fall back to)"
                        )
                        await asyncio.sleep(
                            min(
                                4.0,
                                max(0.0, self.explorer.clock.remaining() - self.strategy.submit_reserve_s - 10),
                            )
                        )
                        result = await self._render(tool_name, role, outcome.prompt, model)
                        uri = _find_image_uri(result) if result is not None else ""
                        if uri:
                            outcome.image_uri = uri
                            outcome.tool = tool_name
                            outcome.model = model
                            self.explorer.harvest_from(result)
                            self._log(f"   Image rendered by {tool_name} with {model}")
                            return outcome
                    break
            if rate_limited:
                break

        if not outcome.image_uri and self.explorer.image_uri:
            # Editing failed: submitting the untouched source is a legal image
            # and still satisfies the submit contract.
            outcome.image_uri = self.explorer.image_uri
            outcome.tool = "input_image_passthrough"
            outcome.error = outcome.error or "all render attempts failed; reusing source image"
        return outcome

    def _ranked_roles(self, roles: dict[str, str], *, wants_edit: bool) -> list[tuple[str, str]]:
        """Order (role, tool) pairs by what the challenge needs.

        An edit tool requires a source image, so it is never tried when the
        challenge has none: the call can only fail argument validation.
        """
        ordered: list[tuple[str, str]] = []
        wanted = ("edit", "generate") if wants_edit else ("generate",)
        for role in wanted:
            for tool_name, tool_role in roles.items():
                if tool_role == role:
                    ordered.append((role, tool_name))
        # An unclassified prompt-taking tool is still a plausible renderer.
        if not ordered:
            for name in self.catalog.names:
                spec = self.catalog.get(name)
                if spec is None:
                    continue
                props = {str(prop).casefold() for prop in spec.properties}
                if props & {"prompt", "instruction"}:
                    ordered.append(("generate", name))
        return ordered

    async def _analyze_source(self, instruction: str) -> str:
        """Describe the source image so an edit can preserve it."""
        if not self.explorer.image_uri:
            return ""
        if _env_mode("EXPLORER_IMAGE_ANALYZE", "auto") == "off":
            return ""
        roles = self.catalog.image_tool_roles()
        analyzers = [name for name, role in roles.items() if role == "analyze"]
        if not analyzers:
            return ""
        if self.explorer.clock.remaining() < self.strategy.submit_reserve_s + 20:
            return ""
        question = (
            "Describe this image precisely for an editing pipeline: subject, composition, "
            "colours, lighting, text, and every element that must be preserved. "
            f"The intended edit is: {instruction}"
        )
        for name in analyzers[:1]:
            observation = await self.explorer.call_tool(
                name,
                {"image_uri": self.explorer.image_uri, "question": question},
                timeout=45.0,
            )
            if observation.ok:
                text = _result_text(observation.result)
                if text:
                    self._think(f"Analyzed the source image ({len(text)} chars)")
                    return text[:2500]
        return ""

    async def _refine_prompt(self, instruction: str, notes: str, analysis: str) -> str:
        """Turn the challenge's instruction into one production prompt.

        An instruction that already states the edit and what to preserve is
        used verbatim: adding to it moves the rendered image away from what the
        judge compares against, and costs a model call for no gain.
        """
        refine_mode = _env_mode("EXPLORER_IMAGE_REFINE", "auto")
        if refine_mode == "never":
            return ""
        if refine_mode != "always" and _is_detailed_instruction(instruction):
            self._log("   Image instruction is already detailed; not rewriting it")
            return ""
        model = self.text_model()
        if not model or self.explorer.clock.remaining() < self.strategy.submit_reserve_s + 15:
            return ""
        system = self.strategy.image_prompt_refiner.format(max_chars=1200)
        editing = bool(self.explorer.image_uri)
        parts = [
            f"Challenge image instruction:\n{instruction}",
        ]
        if notes:
            parts.append(f"Reference notes:\n{notes}")
        if analysis:
            parts.append(f"Analysis of the source image to preserve:\n{analysis}")
        parts.append(
            f"Mode: {'edit the provided source image' if editing else 'generate a new image'}."
        )
        prompt = "\n\n".join(parts)
        reply = await self.explorer._chat(
            model=model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            max_tokens=800,
            timeout=min(40.0, max(10.0, self.explorer.clock.remaining() - self.strategy.submit_reserve_s)),
        )
        if reply.error:
            self._log(f"   Prompt refiner unavailable: {reply.error[:140]}")
            return ""
        text = answers.strip_wrappers(reply.content or "").strip()
        if not text or len(text) < 12:
            return ""
        return text[:1500]

    async def _render(self, tool_name: str, role: str, prompt: str, model: str) -> Any:
        arguments: dict[str, Any] = {"prompt": prompt}
        if role in {"edit", "analyze"} and self.explorer.image_uri:
            arguments["image_uri"] = self.explorer.image_uri
        if role == "analyze":
            arguments["question"] = prompt
        spec = self.catalog.get(tool_name)
        if spec is not None:
            if any(str(prop).casefold() == "model" for prop in spec.properties):
                arguments["model"] = model
            declared = {str(prop).casefold(): prop for prop in spec.properties}
            # Re-key our logical names onto whatever the schema calls them.
            if "image_uri" in arguments and "image_uri" not in declared:
                for candidate in ("image", "input_image", "image_url", "source_image"):
                    if candidate in declared:
                        arguments[declared[candidate]] = arguments.pop("image_uri")
                        break
            if "prompt" in arguments and "prompt" not in declared:
                for candidate in ("instruction", "edit_prompt", "text"):
                    if candidate in declared:
                        arguments[declared[candidate]] = arguments.pop("prompt")
                        break
        observation = await self.explorer.call_tool(
            tool_name,
            arguments,
            timeout=min(120.0, max(20.0, self.explorer.clock.remaining() - self.strategy.submit_reserve_s)),
        )
        if not observation.ok and _prerequisite_error(observation.error):
            # The server said the challenge is not started. Re-read the
            # challenge tool once and retry: a transient gate state costs the
            # whole run if it is treated as a model failure.
            challenge_tool = self.explorer.challenge_tool
            if challenge_tool and self.explorer.clock.remaining() > self.strategy.submit_reserve_s:
                self._log(f"   Prerequisite error from {tool_name}; re-reading {challenge_tool}")
                refreshed = await self.explorer.call_tool(challenge_tool, {})
                if refreshed.ok:
                    observation = await self.explorer.call_tool(tool_name, arguments)
        return observation.result if observation.ok else {"error": observation.error}

    async def submit(
        self,
        outcome: ImageOutcome,
        *,
        client_metrics: dict[str, Any],
        rationale: str,
    ) -> dict[str, Any]:
        """Submit through the discovered image submit tool, if there is one."""
        if not outcome.image_uri:
            return {}
        candidates = [
            name
            for name in self.catalog.submit_candidates(image=True)
            if self.catalog.accepts_any(name, {prop.casefold() for prop in _PAYLOAD_PROPS})
        ]
        for name in candidates:
            spec = self.catalog.get(name)
            if spec is None:
                continue
            arguments: dict[str, Any] = {}
            for prop in spec.required + [prop for prop in spec.properties if prop not in spec.required]:
                lowered = str(prop).casefold()
                if lowered in _PAYLOAD_PROPS:
                    arguments[prop] = outcome.image_uri
                elif lowered in {"client_metrics", "metrics"}:
                    arguments[prop] = dict(client_metrics)
                elif lowered in {"rationale", "reason", "notes"}:
                    arguments[prop] = rationale[:600]
                elif lowered in {"agent_id", "agentid"}:
                    arguments[prop] = self.explorer.agent_id
            observation = await self.explorer.call_tool(name, arguments, timeout=60.0)
            if observation.ok and isinstance(observation.result, dict):
                outcome.required_calls.append(name)
                return observation.result
            if observation.error:
                self._log(f"   Image submit via {name} failed: {observation.error[:160]}")
        return {}


def _with_preservation(prompt: str, *, mode: str) -> str:
    """Append preservation wording for image edits, per the measured mode."""
    text = str(prompt or "").strip()
    if mode == "enumerate":
        clause = (
            "Preserve exactly: the subject's identity and facial features, pose and "
            "body position, framing and camera angle, the background and every object "
            "in it, lighting and shadows, colour balance, and overall image style."
        )
    elif mode == "change_only":
        clause = (
            "Change only the element the instruction names. Leave every other part of "
            "the image as close to the original as possible: same composition, same "
            "background, same lighting, same colours, no added or removed objects."
        )
    else:
        return text
    return f"{text} {clause}" if text else clause


def _is_rate_limit(error: str) -> bool:
    """True when the failure is a proxy rate limit rather than a render error."""
    text = str(error or "").casefold()
    return "429" in text or "rate limit" in text or "too many requests" in text


def _prerequisite_error(error: str) -> bool:
    """True when a tool says its challenge prerequisite has not run."""
    text = str(error or "").casefold()
    return any(
        marker in text
        for marker in (
            "not started",
            "prerequisite",
            "call arena.",
            "must call",
            "before calling",
            "has not been started",
        )
    )


def _tool_error(result: Any) -> str:
    if isinstance(result, dict):
        error = result.get("error")
        if isinstance(error, str) and error.strip():
            return error.strip()
        if isinstance(error, dict) and error:
            return json.dumps(error, ensure_ascii=False)[:300]
    return ""


def _is_detailed_instruction(instruction: str) -> bool:
    """True when the challenge instruction already specifies the image.

    Measured on Practice: rewriting an explicit prompt ("cinematic launch
    poster ... high contrast ... no text") moved the judge's prompt match from
    93 to 92 while costing two seconds, so a prompt at this length is used
    verbatim. Short, vague instructions are still expanded.
    """
    return len(str(instruction or "").split()) >= 18


def _env_mode(name: str, default: str) -> str:
    """Read a dev-only experiment switch; unset means shipped behavior."""
    return (os.getenv(name) or default).strip().casefold()


def _with_constraints(prompt: str, instruction: str, notes: str) -> str:
    """Add a missing prohibition the challenge clearly demanded."""
    text = str(prompt or "").strip()
    source = f"{instruction} {notes}".casefold()
    forbids_text = any(
        token in source
        for token in (
            "no text",
            "without text",
            "avoid text",
            "no logo",
            "no watermark",
            "no lettering",
            "no signage",
        )
    )
    if forbids_text:
        strong = "forbid all text" in text.casefold() or "no text, letters" in text.casefold()
        if not strong:
            # A plain "no text" at the end of a long prompt is a weak signal to
            # an image model; the explicit prohibition measured better on the
            # judge's constraint axis than the verbatim phrase alone.
            clause = "Forbid all text, letters, numbers, logos, signs, and watermarks."
            text = f"{text} {clause}" if text else clause
    return text
