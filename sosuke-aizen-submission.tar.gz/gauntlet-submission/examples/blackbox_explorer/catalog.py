"""Tool catalog for the black-box explorer.

The MCP server is a stranger: tool names, descriptions, and schemas are only
known after ``list_tool_defs()``. This module turns that raw list into a
catalog the rest of the agent can reason over:

- ``ToolSpec``: one discovered tool with a normalized JSON input schema.
- ``ToolCatalog``: naming, rendering, and *semantic* lookups over the specs.
- schema-driven argument synthesis, so a required tool can still be exercised
  when its arguments were never described in prose.

Nothing here knows a specific challenge's tool names. Lookups are token and
schema based (for example "a tool whose name mentions clues and that takes no
required arguments"), which is what keeps the agent usable on an unseen server.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Iterable


# Words that describe a tool's role. Lookups score specs by how many of these
# appear in the tool's name or description.
_TOOL_ROLE_WORDS = {
    "list", "get", "read", "fetch", "show", "describe", "inspect", "find",
    "search", "query", "decode", "encode", "decrypt", "encrypt", "decipher",
    "submit", "send", "post", "write", "save", "execute", "run", "call",
}

# Property names that mean "this is the agent identity".
_AGENT_ID_PROPS = {"agent_id", "agentid", "agent", "session_id", "session"}
# Property names that usually carry the payload of an image tool.
_IMAGE_URI_PROPS = {
    "image_uri", "image_url", "image", "input_image", "input_image_uri",
    "source_image", "image_path", "uri", "url",
}
_PROMPT_PROPS = {"prompt", "instruction", "instructions", "edit_prompt", "description"}
_QUESTION_PROPS = {"question", "query", "q", "prompt", "ask"}
_QUERY_PROPS = {"query", "search_query", "q", "text", "term", "keywords"}
_THOUGHT_PROPS = {"thought", "message", "status", "note", "text"}
_URL_PROPS = {"url", "uri", "link", "href", "video_url"}
_TEXT_PROPS = {"text", "content", "input", "data", "payload", "body"}
_METRICS_PROPS = {"client_metrics", "metrics", "telemetry", "metadata"}
_ANSWER_PROPS = {
    "answer", "edited_image", "image", "output", "result", "response", "solution",
    "value", "final_answer",
}

_TOKEN_SPLIT = re.compile(r"[^a-z0-9]+")


def tokenize(text: str) -> list[str]:
    """Lowercase word tokens, splitting snake_case, kebab-case, and camelCase."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(text or ""))
    return [part for part in _TOKEN_SPLIT.split(spaced.lower()) if part]


def _json_type_label(schema: dict[str, Any]) -> str:
    raw_type = schema.get("type")
    if isinstance(raw_type, str):
        return raw_type
    if isinstance(raw_type, list) and raw_type:
        return "|".join(str(item) for item in raw_type)
    any_of = schema.get("anyOf") or schema.get("oneOf")
    if isinstance(any_of, list):
        labels = [_json_type_label(item) for item in any_of if isinstance(item, dict)]
        labels = [label for label in labels if label and label != "null"]
        return "|".join(dict.fromkeys(labels)) or "any"
    if schema.get("enum"):
        return "|".join(str(item) for item in schema["enum"])
    return "any"


def _is_required_type(schema: dict[str, Any]) -> bool:
    label = _json_type_label(schema)
    return label not in {"null", ""}


@dataclass(frozen=True)
class ToolSpec:
    """One discovered MCP tool."""

    name: str
    description: str
    input_schema: dict[str, Any]
    raw: Any = field(default=None, compare=False)

    @property
    def properties(self) -> dict[str, Any]:
        properties = self.input_schema.get("properties")
        return properties if isinstance(properties, dict) else {}

    @property
    def required(self) -> list[str]:
        required = self.input_schema.get("required")
        if not isinstance(required, list):
            return []
        return [str(item) for item in required if str(item)]

    @property
    def accepts_extra(self) -> bool:
        return bool(self.input_schema.get("additionalProperties"))

    def accepts(self, prop: str) -> bool:
        return prop in self.properties

    def required_props(self) -> list[tuple[str, dict[str, Any]]]:
        return [(name, self.properties.get(name) or {}) for name in self.required]

    def optional_props(self) -> list[tuple[str, dict[str, Any]]]:
        return [
            (name, details if isinstance(details, dict) else {})
            for name, details in self.properties.items()
            if name not in self.required
        ]

    def summary_line(self, *, description_chars: int = 220) -> str:
        """``name(prop: type, prop?: type) - description``."""
        parts: list[str] = []
        for name, details in self.required_props():
            details = details if isinstance(details, dict) else {}
            parts.append(f"{name}: {_json_type_label(details)}")
        for name, details in self.optional_props():
            details = details if isinstance(details, dict) else {}
            parts.append(f"{name}?: {_json_type_label(details)}")
        signature = ", ".join(parts) if parts else "no arguments"
        description = re.sub(r"\s+", " ", self.description or "").strip()
        if len(description) > description_chars:
            description = description[: description_chars - 1].rstrip() + "..."
        if description:
            return f"{self.name}({signature}) - {description}"
        return f"{self.name}({signature})"


class ToolCatalog:
    """Semantic view over a discovered MCP tool list."""

    def __init__(self, tool_defs: Iterable[Any]) -> None:
        specs: dict[str, ToolSpec] = {}
        for tool_def in tool_defs:
            name = str(getattr(tool_def, "name", "") or "").strip()
            if not name:
                continue
            schema = getattr(tool_def, "inputSchema", None)
            if not isinstance(schema, dict):
                schema = {}
            # Inline local $ref/$defs so every consumer (prompt rendering,
            # argument synthesis, provider function schemas) sees one flat
            # shape. Nested-object arguments are common on a real server.
            schema = _inline_refs(schema, schema)
            specs[name] = ToolSpec(
                name=name,
                description=str(getattr(tool_def, "description", "") or "").strip(),
                input_schema=schema,
                raw=tool_def,
            )
        self._specs = specs
        self._names = list(specs)

    # ---- basic access ----------------------------------------------------
    def __len__(self) -> int:
        return len(self._specs)

    def __contains__(self, name: str) -> bool:
        return name in self._specs

    @property
    def names(self) -> list[str]:
        return list(self._names)

    def get(self, name: str) -> ToolSpec | None:
        return self._specs.get(name)

    def require(self, name: str) -> ToolSpec:
        spec = self.get(name)
        if spec is None:
            raise KeyError(f"tool not in catalog: {name}")
        return spec

    def describe(self, name: str, *, chars: int = 400) -> str:
        spec = self.get(name)
        return spec.summary_line(description_chars=chars) if spec else f"{name}(?)"

    def render(self) -> str:
        """The catalog as compact text for a model prompt."""
        lines = []
        for name in self._names:
            lines.append(f"- {self.describe(name)}")
        return "\n".join(lines)

    # ---- semantic lookups ------------------------------------------------
    def score(self, name: str, wanted: Iterable[str], *, forbidden: Iterable[str] = ()) -> int:
        """Token overlap between a tool's name/description and wanted words."""
        spec = self.get(name)
        if spec is None:
            return -1
        name_tokens = set(tokenize(name))
        text_tokens = set(tokenize(f"{name} {spec.description}"))
        wanted_set = {word.casefold() for word in wanted}
        forbidden_set = {word.casefold() for word in forbidden}
        if name_tokens & forbidden_set or text_tokens & forbidden_set:
            return -1
        return 3 * len(name_tokens & wanted_set) + len(text_tokens & wanted_set)

    def rank(self, wanted: Iterable[str], *, forbidden: Iterable[str] = ()) -> list[str]:
        scored = [
            (self.score(name, wanted, forbidden=forbidden), index, name)
            for index, name in enumerate(self._names)
        ]
        scored = [(score, index, name) for score, index, name in scored if score > 0]
        scored.sort(key=lambda item: (-item[0], item[1]))
        return [name for _score, _index, name in scored]

    def match(self, *wanted: str, forbidden: Iterable[str] = ()) -> list[str]:
        return self.rank(wanted, forbidden=forbidden)

    def first_without_required(self, candidates: Iterable[str]) -> str:
        for name in candidates:
            spec = self.get(name)
            if spec is not None and not spec.required:
                return name
        return ""

    # ---- role helpers used by the explorer ------------------------------
    def challenge_candidates(self, *, image: bool) -> list[str]:
        """Tools that plausibly return a task payload (ranked)."""
        wanted = ("challenge", "task", "puzzle", "briefing", "mission", "assignment")
        forbidden = ()
        if image:
            ranked = self.rank(wanted + ("image",))
            if not ranked:
                ranked = self.rank(wanted)
            return ranked
        # A text run must not bootstrap on an image-only challenge tool.
        return [name for name in self.rank(wanted) if "image" not in set(tokenize(name))]

    def clue_list_candidates(self) -> list[str]:
        candidates = self.rank(("clues", "clue", "hints", "hint", "list"))
        return [
            name
            for name in candidates
            if "clue" in set(tokenize(name)) or "hint" in set(tokenize(name))
        ]

    def time_candidates(self) -> list[str]:
        return self.rank(("time", "remaining", "clock", "deadline", "timer"))

    def tools_list_candidates(self) -> list[str]:
        return [
            name
            for name in self.rank(("tools", "tool", "list", "discover", "capabilities", "functions"))
            if "tool" in set(tokenize(name))
        ]

    def thought_candidates(self) -> list[str]:
        return self.rank(("thought", "broadcast", "status", "progress", "log"))

    def image_tool_roles(self) -> dict[str, str]:
        """Classify discovered tools into image edit/generate/analyze roles.

        Heuristics, in priority order, over the schema first and the name
        second. A tool that requires an image URI and a prompt edits; a tool
        that requires only a prompt generates; a tool that requires an image
        URI and a question analyzes.
        """
        roles: dict[str, str] = {}
        for spec in self._specs.values():
            name_tokens = set(tokenize(spec.name))
            if "image" not in name_tokens and not any(
                _normalize(prop) in _IMAGE_URI_PROPS for prop in spec.required
            ):
                continue
            required = {_normalize(prop) for prop in spec.required}
            takes_image = bool(required & _IMAGE_URI_PROPS)
            takes_prompt = bool(required & (_PROMPT_PROPS | _QUESTION_PROPS))
            if "analy" in spec.name.casefold() or "analy" in spec.description.casefold():
                roles[spec.name] = "analyze"
            elif takes_image and takes_prompt:
                roles[spec.name] = "edit"
            elif takes_image and not takes_prompt:
                roles[spec.name] = "analyze"
            elif takes_prompt and not takes_image:
                roles[spec.name] = "generate"
        return roles

    def submit_candidates(self, *, image: bool) -> list[str]:
        """Tools that plausibly submit a final answer."""
        wanted = ("submit", "finalize", "answer", "score", "send")
        ranked = self.rank(wanted)
        if image:
            image_ranked = [name for name in ranked if "image" in set(tokenize(name))]
            return image_ranked + [name for name in ranked if name not in image_ranked]
        return [name for name in ranked if "image" not in set(tokenize(name))]

    def accepts_any(self, name: str, props: set[str]) -> bool:
        spec = self.get(name)
        if spec is None:
            return False
        declared = {_normalize(prop) for prop in spec.properties}
        return bool(declared & props)

    # ---- argument handling ----------------------------------------------
    def sanitize_arguments(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Drop undeclared keys that a strict server would reject."""
        spec = self.get(name)
        if spec is None:
            return dict(arguments)
        if spec.accepts_extra or not spec.properties:
            return dict(arguments)
        cleaned: dict[str, Any] = {}
        for key, value in arguments.items():
            if key in spec.properties:
                cleaned[key] = coerce_value(spec.properties[key], value)
        return cleaned

    def missing_required(self, name: str, arguments: dict[str, Any]) -> list[str]:
        spec = self.get(name)
        if spec is None:
            return []
        return [
            prop
            for prop in spec.required
            if prop not in arguments or arguments.get(prop) in (None, "")
        ]

    def synthesize_arguments(
        self,
        name: str,
        context: dict[str, Any],
    ) -> tuple[dict[str, Any], list[str]]:
        """Build arguments from a known-value bag, guided by the schema.

        Returns the arguments that could be filled confidently plus the
        required properties still missing. A missing list means the call is
        safe to attempt without a model round trip.
        """
        spec = self.get(name)
        if spec is None:
            return {}, []
        arguments: dict[str, Any] = {}
        for prop, details in spec.properties.items():
            details = details if isinstance(details, dict) else {}
            value = _context_value(prop, details, context)
            if value is not None:
                arguments[prop] = coerce_value(details, value)
        # Agent identity is always safe to include when the schema asks for it.
        for prop in spec.properties:
            if _normalize(prop) in _AGENT_ID_PROPS and prop not in arguments:
                agent_id = str(context.get("agent_id") or "").strip()
                if agent_id:
                    arguments[prop] = agent_id
        missing = [
            prop
            for prop in spec.required
            if prop not in arguments or arguments.get(prop) in (None, "")
        ]
        return arguments, missing


def _normalize(prop: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(prop).casefold()).strip("_")


def _inline_refs(node: Any, root: Any, depth: int = 0) -> Any:
    """Resolve local JSON-schema ``$ref`` pointers against the root schema."""
    if depth > 8:
        return node
    if isinstance(node, dict):
        ref = node.get("$ref")
        if isinstance(ref, str) and ref.startswith("#/"):
            target: Any = root
            for part in ref[2:].split("/"):
                if isinstance(target, dict) and part in target:
                    target = target[part]
                else:
                    target = None
                    break
            if isinstance(target, dict):
                merged = {key: value for key, value in node.items() if key != "$ref"}
                resolved = _inline_refs(target, root, depth + 1)
                if isinstance(resolved, dict):
                    merged = {**resolved, **merged}
                return merged
        return {
            key: _inline_refs(value, root, depth + 1)
            for key, value in node.items()
            if key != "$defs"
        }
    if isinstance(node, list):
        return [_inline_refs(item, root, depth + 1) for item in node]
    return node


def _context_value(
    prop: str,
    details: dict[str, Any],
    context: dict[str, Any],
) -> Any:
    """Pick a value for ``prop`` from the context bag, by name or type."""
    normalized = _normalize(prop)
    # An explicit value wins over every heuristic. The per-identifier expansion
    # passes ``clue_id`` for each clue, and a scalar harvested from the first
    # clue must never override the identifier being worked on.
    explicit = context.get(normalized)
    if explicit not in (None, ""):
        return explicit
    groups: tuple[tuple[set[str], str], ...] = (
        (_AGENT_ID_PROPS, "agent_id"),
        (_THOUGHT_PROPS, "thought"),
        (_IMAGE_URI_PROPS, "image_uri"),
        (_QUESTION_PROPS, "question"),
        (_PROMPT_PROPS, "prompt"),
        (_QUERY_PROPS, "query"),
        (_URL_PROPS, "url"),
        (_ANSWER_PROPS, "answer"),
        (_METRICS_PROPS, "metrics"),
        (_TEXT_PROPS, "text"),
    )
    for names, key in groups:
        if normalized in names:
            value = context.get(key)
            if value not in (None, ""):
                return value
    # A named scalar a previous tool returned under exactly this key (for
    # example "nonce", "token", or "key") is the most likely handle.
    scalars = context.get("scalars")
    if isinstance(scalars, dict):
        scalar = scalars.get(normalized)
        if scalar not in (None, ""):
            return scalar
    # A property that literally names a value we already hold (for example
    # "clue_id" while working through clue_3) wins over any group default.
    if normalized.endswith("_id"):
        stem = normalized[: -len("_id")]
        for key in (f"{stem}_id", stem, f"{stem}s"):
            value = context.get(key)
            if value not in (None, ""):
                return value
        values = context.get("id_pool")
        if isinstance(values, (list, tuple)):
            for value in values:
                if normalized in _normalize(str(value)):
                    return value
    # Arrays of strings: reuse a single known string, the schema validates.
    label = _json_type_label(details)
    if label == "array":
        for key in ("id_pool", "clues", "texts"):
            value = context.get(key)
            if isinstance(value, (list, tuple)) and value:
                return list(value)[:12]
    if label == "object":
        # An object whose own fields are optional can be sent empty and let
        # the server apply its declared defaults. That is how a nested-filter
        # tool becomes callable without inventing a shape.
        nested_required = details.get("required")
        if not nested_required:
            return {}
    return None


def coerce_value(schema: dict[str, Any], value: Any) -> Any:
    """Coerce a value to the schema's declared type, best effort."""
    label = _json_type_label(schema)
    try:
        if label in {"string", "str"}:
            if isinstance(value, str):
                return value
            if isinstance(value, (dict, list)):
                return json.dumps(value, ensure_ascii=False)
            return str(value)
        if label in {"integer", "int"}:
            return int(value)
        if label in {"number", "float"}:
            return float(value)
        if label in {"boolean", "bool"}:
            if isinstance(value, str):
                return value.strip().casefold() in {"1", "true", "yes", "on"}
            return bool(value)
        if label == "object":
            if isinstance(value, dict):
                return value
            if isinstance(value, str):
                parsed = json.loads(value)
                return parsed if isinstance(parsed, dict) else {"value": parsed}
            return {"value": value}
        if label == "array":
            if isinstance(value, list):
                return value
            if isinstance(value, (tuple, set)):
                return list(value)
            return [value]
    except (TypeError, ValueError, json.JSONDecodeError):
        return value
    return value


def render_value(value: Any, *, max_chars: int = 700, depth: int = 0) -> str:
    """Render a tool result for a model transcript, eliding bulky payloads."""
    if depth > 4:
        return "..."
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        text = value
        if text.startswith("data:") and len(text) > 120:
            return f"<inline data URI, {len(text)} chars>"
        text = re.sub(r"\s+", " ", text).strip()
        return _truncate(text, max_chars)
    if isinstance(value, (list, tuple)):
        rendered = [render_value(item, max_chars=max_chars // 2, depth=depth + 1) for item in list(value)[:20]]
        if len(value) > 20:
            rendered.append(f"... {len(value) - 20} more")
        return "[" + ", ".join(rendered) + "]"
    if isinstance(value, dict):
        parts = []
        for index, (key, item) in enumerate(value.items()):
            if index >= 30:
                parts.append("...")
                break
            parts.append(f"{key}={render_value(item, max_chars=max_chars // 2, depth=depth + 1)}")
        return "{" + ", ".join(parts) + "}"
    return _truncate(str(value), max_chars)


def _truncate(text: str, limit: int) -> str:
    if limit <= 0 or len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "..."


def flatten_text(value: Any, *, max_chars: int = 4000) -> str:
    """Flatten a nested result into plain text for evidence prompts."""
    pieces: list[str] = []

    def walk(node: Any, label: str = "") -> None:
        if sum(len(piece) for piece in pieces) > max_chars:
            return
        if isinstance(node, dict):
            for key, item in node.items():
                walk(item, str(key))
        elif isinstance(node, (list, tuple)):
            for item in node[:20]:
                walk(item, label)
        elif isinstance(node, str):
            text = node.strip()
            if text.startswith("data:") and len(text) > 120:
                # Never let an inline image blow up an evidence transcript.
                pieces.append(f"{label or 'image'}: <inline image data, {len(text)} chars>")
                return
            if text:
                prefix = f"{label}: " if label and label not in text else ""
                pieces.append(prefix + text)
        elif isinstance(node, (int, float, bool)):
            if label:
                pieces.append(f"{label}: {node}")

    walk(value)
    text = "\n".join(pieces)
    return _truncate(text, max_chars)
